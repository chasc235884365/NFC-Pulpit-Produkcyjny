/*
 * TapCraft NFC - serwer v7.8 (Node.js + SQLite) - bezpieczenstwo + RODO
 * Obsługa breloków NFC + automatyczny monit GPS + oryginalne logo SVG z paczki.
 * Uruchamiane na VPS (Mikrus: wanda350) za pomocą PM2 + Cytrus (tapcraft.cytr.us).
 */
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import Database from 'better-sqlite3';
import dotenv from 'dotenv';

const __dir = path.dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: path.join(__dir, '.env') });

// ---------- Wczytanie oryginalnych plików SVG z folderu /root/ringtag/svg/ ----------
function loadLogoSvg(filename, cssStyle) {
  try {
    const filePath = path.join(__dir, 'svg', filename);
    let svg = fs.readFileSync(filePath, 'utf8');
    // Usunięcie deklaracji XML jeśli występuje oraz wstrzyknięcie stylu rozmiaru
    svg = svg.replace(/<\?xml[^>]*\?>/gi, '').trim();
    svg = svg.replace(/<svg\b([^>]*)>/i, (_, attrs) => {
      const cleanedAttrs = attrs.replace(/\s(width|height|style)="[^"]*"/gi, '');
      return `<svg${cleanedAttrs} style="${cssStyle}">`;
    });
    return svg;
  } catch (e) {
    console.warn(`[Logo] Nie znaleziono pliku svg/${filename} - używam tekstu zastępczego.`);
    return `<span style="font-weight:800;font-size:22px;letter-spacing:-0.02em">Tap<span style="color:#38bdf8">Craft</span></span>`;
  }
}

const LOGO_PIONOWE_CIEMNE = loadLogoSvg('tapcraft-logo-pionowe-na-ciemnym.svg', 'height:112px;width:auto;display:block;margin:0 auto 18px');
const LOGO_POZIOME_JASNE  = loadLogoSvg('tapcraft-logo-poziome-na-jasnym.svg', 'height:32px;width:auto;display:block');

// ---------- Baza (SQLite) udająca Cloudflare KV ----------
const DB_PATH = process.env.DB_PATH || path.join(__dir, 'database.sqlite');
const db = new Database(DB_PATH);
db.exec('CREATE TABLE IF NOT EXISTS tags (tag_id TEXT PRIMARY KEY, data TEXT NOT NULL);');
const dbGet = db.prepare('SELECT data FROM tags WHERE tag_id = ?');
const dbPut = db.prepare('INSERT INTO tags (tag_id, data) VALUES (?, ?) ON CONFLICT(tag_id) DO UPDATE SET data = excluded.data');

const REDIRECTS = {
  async get(key) { const row = dbGet.get(String(key)); return row ? row.data : null; },
  async put(key, value) { dbPut.run(String(key), String(value)); }
};

const env = {
  PORT: Number(process.env.PORT) || 3000,
  BASE_URL: (process.env.BASE_URL || 'https://tapcraft.cytr.us').replace(/\/+$/, ''),
  API_SECRET: process.env.API_SECRET || '',
  API_ADMIN_SECRET: process.env.API_ADMIN_SECRET || '',
  TELEGRAM_TOKEN: process.env.TELEGRAM_TOKEN || '',
  TELEGRAM_BOT_NAME: (process.env.TELEGRAM_BOT_NAME || '').replace(/^@/, ''),
  TELEGRAM_WEBHOOK_SECRET: process.env.TELEGRAM_WEBHOOK_SECRET || '',
  RESEND_API_KEY: process.env.RESEND_API_KEY || '',
  MAIL_FROM: process.env.MAIL_FROM || '',
  LEGAL_NAME: process.env.LEGAL_NAME || 'TapCraft',
  CONTACT_EMAIL: process.env.CONTACT_EMAIL || '',
  REDIRECTS
};

function cleanIp(raw) {
  let ip = String(raw || '').split(',')[0].trim();
  if (ip.startsWith('::ffff:')) ip = ip.slice(7);
  return ip || 'unknown';
}

// --- Zrodlo IP klienta ---
// TRUST_PROXY=0  -> uzywaj tylko adresu gniazda (gdy serwer stoi bez proxy).
// IP_HEADER=...  -> naglowek ustawiany przez Twoje proxy (np. x-real-ip, cf-connecting-ip).
// domyslnie      -> OSTATNI wpis x-forwarded-for (dopisuje go proxy; pierwszy moze podrobic klient).
const TRUST_PROXY = process.env.TRUST_PROXY !== '0';
const IP_HEADER = (process.env.IP_HEADER || '').trim().toLowerCase();
const listOf = (v) => String(v || '').split(',').map((x) => x.trim()).filter(Boolean);
function clientIp(req) {
  const sock = cleanIp(req.socket.remoteAddress || 'unknown');
  if (!TRUST_PROXY) return sock;
  if (IP_HEADER) { const l = listOf(req.headers[IP_HEADER]); if (l.length) return cleanIp(l[0]); }
  const xff = listOf(req.headers['x-forwarded-for']);
  if (xff.length) return cleanIp(xff[xff.length - 1]);
  return sock;
}
function isPrivateIp(ip) {
  return !ip || ip === 'unknown' || ip === '::1' || ip === '::' || /^(127\.|10\.|192\.168\.|169\.254\.|172\.(1[6-9]|2\d|3[01])\.)/.test(ip) || /^(fc|fd|fe80)/i.test(ip);
}

// Geolokalizacja IP. GEO_PROVIDER: ipwho (domyslnie, HTTPS) | ipapi (stare, HTTP) | off (nic nie wysylamy do osob trzecich)
const GEO_PROVIDER = (process.env.GEO_PROVIDER || 'ipwho').toLowerCase();
const geoCache = new Map();
async function geoPlace(rawIp) {
  const none = 'nieznane miejsce';
  try {
    if (GEO_PROVIDER === 'off') return none;
    const ip = cleanIp(rawIp);
    if (isPrivateIp(ip)) return none;
    const c = geoCache.get(ip);
    if (c && c.exp > Date.now()) return c.v;
    let place = none;
    if (GEO_PROVIDER === 'ipapi') {
      const r = await fetch(`http://ip-api.com/json/${encodeURIComponent(ip)}?fields=status,city,country`, { signal: AbortSignal.timeout(2500) });
      if (r.ok) { const g = await r.json(); if (!g.status || g.status === 'success') place = [g.city, g.country].filter(Boolean).join(', ') || none; }
    } else {
      const r = await fetch(`https://ipwho.is/${encodeURIComponent(ip)}?fields=success,city,country`, { signal: AbortSignal.timeout(2500) });
      if (r.ok) { const g = await r.json(); if (g.success !== false) place = [g.city, g.country].filter(Boolean).join(', ') || none; }
    }
    if (geoCache.size > 2000) geoCache.clear();
    geoCache.set(ip, { v: place, exp: Date.now() + 3600_000 });
    return place;
  } catch (e) { return none; }
}

const BRAND = process.env.BRAND || 'TapCraft';

const MODES = ['pet', 'lost', 'biz', 'link', 'hub', 'pay', 'ice', 'wifi'];

const LINES = {
  pet: ['pet'],
  safe: ['lost', 'ice'],
  pro: ['biz', 'link', 'hub', 'pay'],
  home: ['wifi']
};

const LINE_PREFIXES = {
  pet: 'pet-',
  safe: 'safe-',
  pro: 'pro-',
  home: 'home-',
  all: 'all-'
};

function parseLine(body) {
  if (body.line === undefined && body.modes === undefined) return { list: null };
  if (body.line === 'all') return { list: null };
  const raw = Array.isArray(body.modes) ? body.modes : LINES[body.line];
  const list = raw ? [...new Set(raw.filter((m) => MODES.includes(m)))] : [];
  return list.length
    ? { list }
    : { error: 'Podaj line (' + Object.keys(LINES).join(', ') + ', all) albo modes: [...].' };
}

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, X-Api-Secret, X-Api-Admin',
};

const CSP = "default-src 'none'; script-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com; " +
  "style-src 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; " +
  "form-action 'self'; base-uri 'none'; frame-ancestors 'none'";

const mem = new Map();
function hit(key, ms) {
  const now = Date.now();
  const until = mem.get(key);
  if (until && until > now) return false;
  mem.set(key, now + ms);
  if (mem.size > 2000) for (const [k, v] of mem) if (v < now) mem.delete(k);
  return true;
}

const WINDOW = 10 * 60 * 1000;
const fails = new Map();
const isLocked = (key) => (fails.get(key)?.until || 0) > Date.now();
const failLimit = (key) => (String(key).startsWith('tag:') ? 30 : 8);
function pruneMap(m, max, isDead) {
  if (m.size <= max) return;
  const now = Date.now();
  for (const [k, v] of m) if (isDead(v, now)) m.delete(k);
  let drop = m.size - max;
  if (drop > 0) for (const k of m.keys()) { if (drop-- <= 0) break; m.delete(k); }
}
function registerFail(...keys) {
  const now = Date.now();
  for (const key of keys) {
    const f = fails.get(key) || { n: 0, until: 0, ts: now };
    if (f.until < now && now - f.ts > WINDOW) f.n = 0;
    f.ts = now; f.n++;
    if (f.n >= failLimit(key)) { f.until = now + WINDOW; f.n = 0; }
    fails.delete(key); fails.set(key, f);
  }
  pruneMap(fails, 5000, (v, now) => v.until < now && now - v.ts > WINDOW);
}

const rates = new Map();
function rate(key, limit, ms) {
  const now = Date.now();
  let r = rates.get(key);
  if (!r || r.reset < now) { r = { n: 0, reset: now + ms }; rates.set(key, r); }
  r.n++;
  pruneMap(rates, 5000, (v, t) => v.reset < t);
  return r.n <= limit;
}

const ALPHA = 'abcdefghjkmnpqrstuvwxyz23456789';
const POLICY_VER = '2026-11-25'; // zmien przy kazdej istotnej zmianie polityki - wymusi ponowna zgode na dane zdrowotne
const ID_LEN = Math.min(16, Math.max(6, Number(process.env.ID_LEN) || 8));
const randomId = (n = ID_LEN) => {
  const lim = 256 - (256 % ALPHA.length);
  let out = '';
  while (out.length < n) {
    for (const x of crypto.getRandomValues(new Uint8Array(n * 2))) {
      if (x < lim && out.length < n) out += ALPHA[x % ALPHA.length];
    }
  }
  return out;
};

const randomPin = () =>
  String(100000 + (crypto.getRandomValues(new Uint32Array(1))[0] % 900000));

function safeEqual(a, b) {
  a = String(a || ''); b = String(b || '');
  if (a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}

const NONCE_SECRET = process.env.TELEGRAM_WEBHOOK_SECRET || process.env.API_SECRET || crypto.randomBytes(32).toString('hex');
const geoSig = (tagId, ts) => crypto.createHmac('sha256', NONCE_SECRET).update('geo:' + tagId + ':' + ts).digest('hex').slice(0, 20);
const geoNonce = (tagId) => { const ts = Math.floor(Date.now() / 1000); return ts + '.' + geoSig(tagId, ts); };
function verifyGeoNonce(tagId, n) {
  const [ts, sig] = String(n || '').split('.');
  const t = Number(ts);
  if (!Number.isFinite(t) || !sig) return false;
  const age = Date.now() / 1000 - t;
  if (age < -60 || age > 7200) return false;
  return safeEqual(sig, geoSig(tagId, ts));
}
function apiOk(request, ip) {
  if (isLocked(ip)) return false;
  const ok = Boolean(env.API_SECRET) && safeEqual(request.headers.get('X-Api-Secret'), env.API_SECRET);
  if (!ok) registerFail(ip);
  return ok;
}

const validId = (s) => /^[A-Za-z0-9_-]{1,64}$/.test(s || '');
const safeDecode = (s) => { try { return decodeURIComponent(s); } catch (e) { return ''; } };
const parse = (raw) => { try { const v = JSON.parse(raw); return v && typeof v === 'object' ? v : null; } catch (e) { return null; } };

async function loadTag(env, tagId, fresh = false) {
  const raw = fresh
    ? await env.REDIRECTS.get(tagId)
    : await env.REDIRECTS.get(tagId, { cacheTtl: 60 });
  return parse(raw);
}

const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) =>
  ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function telNum(p) {
  let clean = String(p || '').replace(/[^\d+]/g, '');
  if (!clean) return '';
  if (!clean.startsWith('+') && clean.length === 9) clean = '+48' + clean;
  return clean;
}

const jsonForScript = (v) => JSON.stringify(v).replace(/</g, '\\u003c');
const fullUrl = (u) => (/^https?:\/\//i.test(u) ? u : 'https://' + u);

function handleUrl(v, base) {
  v = String(v || '').trim();
  if (!v) return '';
  if (/^https?:\/\//i.test(v)) return v;
  return base + v.replace(/^@/, '');
}

function getScanHeadline(data, tagId) {
  if (!data) return '🔔 Ktoś zeskanował Twój brelok #' + tagId;
  switch (data.type) {
    case 'pet':
      return data.petName 
        ? '🔔 Ktoś zeskanował obrożę Twojego zwierzaka (' + data.petName + ')' 
        : '🔔 Ktoś zeskanował obrożę Twojego zwierzaka';
    case 'lost':
      return data.lostItem 
        ? '🔔 Ktoś zeskanował Twoją zgubę (' + data.lostItem + ')' 
        : '🔔 Ktoś zeskanował Twój zgubiony przedmiot';
    case 'biz':
      return data.name 
        ? '🔔 Ktoś otworzył Twoją wizytówkę (' + data.name + ')' 
        : '🔔 Ktoś otworzył Twoją wizytówkę';
    case 'hub':
      return data.hubName 
        ? '🔔 Ktoś otworzył Twój profil z linkami (' + data.hubName + ')' 
        : '🔔 Ktoś otworzył Twój profil z linkami';
    case 'ice':
      return data.iceName 
        ? '🚨 Ktoś otworzył Twoją kartę ratunkową ICE (' + data.iceName + ')' 
        : '🚨 Ktoś otworzył Twoją kartę ratunkową ICE';
    case 'wifi':
      return data.ssid 
        ? '🔔 Ktoś zeskanował dostęp do Wi-Fi (' + data.ssid + ')' 
        : '🔔 Ktoś zeskanował dostęp do Twojego Wi-Fi';
    case 'pay':
      return data.pPurpose 
        ? '🔔 Ktoś otworzył dane do płatności (' + data.pPurpose + ')' 
        : '🔔 Ktoś otworzył Twoje dane do płatności';
    case 'link':
      return '🔔 Ktoś zeskanował Twój brelok z linkiem';
    default:
      return '🔔 Ktoś zeskanował Twój brelok #' + tagId;
  }
}

function getPairLabel(data) {
  const d = data || {};
  switch (d.type) {
    case 'pet':  return d.petName ? '🐾 Zwierzak – ' + d.petName : '🐾 Zwierzak';
    case 'lost': return d.lostItem ? '🔑 Zguba – ' + d.lostItem : '🔑 Zgubiony przedmiot';
    case 'biz':  return '💼 Wizytówka';
    case 'hub':  return '📱 Social media';
    case 'ice':  return '🚑 Karta ratunkowa';
    case 'wifi': return '📶 Wi-Fi dla gości';
    case 'pay':  return '💳 Płatności i napiwki';
    case 'link': return '🔗 Link do strony';
    default:     return '🏷️ Twój brelok';
  }
}

function safeRedirect(u) {
  try {
    if (!u) return null;
    const t = new URL(fullUrl(String(u).trim()));
    if (t.protocol !== 'https:' && t.protocol !== 'http:') return null;
    return new Response(null, {
      status: 302,
      headers: { Location: t.href, 'Cache-Control': 'private, max-age=60', 'Referrer-Policy': 'no-referrer' }
    });
  } catch (e) { return null; }
}

const htmlRes = (body, status = 200, cacheControl = 'no-store, no-cache, must-revalidate') => new Response(body, {
  status,
  headers: {
    'Content-Type': 'text/html;charset=UTF-8',
    'Cache-Control': cacheControl,
    'Content-Security-Policy': CSP,
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'same-origin',
    'X-Robots-Tag': 'noindex',
    'Strict-Transport-Security': 'max-age=15552000'
  }
});

function addPreviewBar(html, tagId, token, origin) {
  const back = `${origin}/admin?tag=${encodeURIComponent(tagId)}&token=${encodeURIComponent(token)}`;
  const bar = `<div style="height:80px"></div>
<div style="position:fixed;left:0;right:0;bottom:0;z-index:300;display:flex;align-items:center;justify-content:space-between;gap:12px;padding:12px 16px calc(12px + env(safe-area-inset-bottom));background:#0f172a;color:#fff;font:600 14px/1.3 -apple-system,'Segoe UI',Roboto,sans-serif;box-shadow:0 -8px 24px rgba(0,0,0,.25)">
<span>Podgląd: tak widzą Twój brelok inni.</span>
<a href="${esc(back)}" style="flex:none;padding:10px 14px;border-radius:10px;background:#fff;color:#0f172a;font-weight:800;text-decoration:none">Wróć do edycji</a></div>`;
  return html.replace('</body>', () => bar + '</body>');
}

const jsonRes = (obj, status = 200) => new Response(JSON.stringify(obj), {
  status,
  headers: {
    'Content-Type': 'application/json',
    'Cache-Control': 'no-store, no-cache, must-revalidate',
    ...CORS_HEADERS
  }
});

const BOT_RE = /(^|[^a-z])bot([^a-z]|$)|googlebot|bingbot|applebot|yandex|duckduck|baidu|twitterbot|petalbot|semrush|ahrefs|crawl|spider|preview|slurp|facebookexternalhit|whatsapp|telegram|discord|slack|skype|linkedin|embedly|curl|wget|python|headless|monitor/i;
const isBot = (request) => {
  const ua = request.headers.get('user-agent') || '';
  return !ua || BOT_RE.test(ua);
};

const alertsOn = (d, env) =>
  d.notifyActive === '1' &&
  Boolean((d.notifyTg && env.TELEGRAM_TOKEN) || (d.notifyEmail && env.RESEND_API_KEY && env.MAIL_FROM));

const worker = {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const p = url.pathname;
    const ip = cleanIp(request.headers.get('cf-connecting-ip') || request.headers.get('x-forwarded-for'));

    if (request.method === 'OPTIONS') {
      return new Response(null, {
        status: 204,
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
          'Access-Control-Allow-Headers': 'Content-Type, X-Api-Secret, X-Api-Admin',
          'Access-Control-Max-Age': '86400',
        }
      });
    }

    if (p === '/favicon.ico' || p.includes('apple-touch-icon') || /\.(png|ico|svg|webmanifest)$/.test(p)) {
      return new Response(null, { status: 204, headers: { 'Cache-Control': 'public, max-age=86400' } });
    }

    if (p === '/healthz') {
      try { dbGet.get('__health__'); } catch (e) { return new Response('db error', { status: 500 }); }
      if (env.API_SECRET && safeEqual(request.headers.get('X-Api-Secret'), env.API_SECRET)) {
        const h = (k) => request.headers.get(k) || '';
        return jsonRes({ ok: true, v: '7.8', ip, trustProxy: TRUST_PROXY, ipHeader: IP_HEADER || 'x-forwarded-for (ostatni wpis)',
          diag: { 'x-forwarded-for': h('x-forwarded-for'), 'x-real-ip': h('x-real-ip'), forwarded: h('forwarded'), host: h('host') } });
      }
      return new Response('ok', { status: 200, headers: { 'Cache-Control': 'no-store' } });
    }

    if (p === '/privacy') {
      return htmlRes(renderPrivacy(url.hostname, env), 200, 'public, max-age=86400');
    }

    if (p === '/api/create-tag' && request.method === 'POST') {
      if (!apiOk(request, ip)) {
        return jsonRes({ error: 'Nieautoryzowany dostęp.' }, 403);
      }
      const body = await request.json().catch(() => ({}));
      let tagId = String(body.tagId || '').trim();
      const lineChoice = String(body.line || 'all').toLowerCase();

      if (tagId) {
        if (!validId(tagId)) return jsonRes({ error: 'Zły tagId.' }, 400);
        if (await env.REDIRECTS.get(tagId)) return jsonRes({ error: 'Taki tagId już istnieje.' }, 409);
      } else {
        const prefix = LINE_PREFIXES[lineChoice] || '';
        for (let i = 0; i < 5 && !tagId; i++) {
          const candidate = prefix + randomId();
          if (!(await env.REDIRECTS.get(candidate))) tagId = candidate;
        }
        if (!tagId) return jsonRes({ error: 'Nie udało się wygenerować ID.' }, 500);
      }

      const line = parseLine(body);
      if (line.error) return jsonRes({ error: line.error }, 400);

      const token = crypto.randomUUID();
      const claimPin = randomPin();
      const record = {
        token,
        type: line.list ? line.list[0] : 'new',
        notifyActive: '1',
        createdAt: new Date().toISOString(),
        status: 'unclaimed',
        claimPin
      };

      if (line.list) record.allowed = line.list;
      if (MODES.includes(body.type) && (!line.list || line.list.includes(body.type))) record.type = body.type;

      await env.REDIRECTS.put(tagId, JSON.stringify(record));
      return jsonRes({
        tagId,
        token,
        claimPin,
        status: 'unclaimed',
        allowed: line.list || 'all',
        tagUrl: `${url.origin}/tag/${tagId}`,
        adminUrl: `${url.origin}/admin?tag=${tagId}&token=${token}`
      });
    }

    if (p === '/api/update-tag' && request.method === 'POST') {
      if (!apiOk(request, ip)) {
        return jsonRes({ error: 'Nieautoryzowany dostęp.' }, 403);
      }
      const body = await request.json().catch(() => ({}));
      const tagId = String(body.tagId || '');
      if (!validId(tagId)) return jsonRes({ error: 'Zły tagId.' }, 400);

      const hasLineOrModes = body.line !== undefined || body.modes !== undefined;
      const hasStatus = body.status !== undefined;
      const hasRotate = body.rotateToken === true;
      if (!hasLineOrModes && !hasStatus && !hasRotate) return jsonRes({ error: 'Podaj line, modes, status lub rotateToken.' }, 400);

      const line = parseLine(body);
      if (hasLineOrModes && line.error) return jsonRes({ error: line.error }, 400);

      const data = await loadTag(env, tagId, true);
      if (!data) return jsonRes({ error: 'Tag nie istnieje.' }, 404);

      if (hasLineOrModes) {
        if (line.list) {
          data.allowed = line.list;
          if (!line.list.includes(data.type)) data.type = line.list[0];
        } else {
          delete data.allowed;
        }
      }

      if (body.status === 'active') {
        data.status = 'active';
        delete data.claimPin;
      } else if (body.status === 'unclaimed') {
        data.status = 'unclaimed';
        if (!data.claimPin) data.claimPin = randomPin();
      }

      if (hasRotate) data.token = crypto.randomUUID();
      await env.REDIRECTS.put(tagId, JSON.stringify(data));
      return jsonRes({
        tagId,
        status: data.status || 'active',
        claimPin: data.claimPin || null,
        allowed: data.allowed || 'all',
        ...(hasRotate ? { token: data.token, adminUrl: `${url.origin}/admin?tag=${encodeURIComponent(tagId)}&token=${encodeURIComponent(data.token)}` } : {})
      });
    }

    if (p === '/api/get-tag' && request.method === 'POST') {
      if (!apiOk(request, ip)) {
        return jsonRes({ error: 'Nieautoryzowany dostęp (zły API_SECRET).' }, 403);
      }
      const body = await request.json().catch(() => ({}));
      const tagId = String(body.tagId || '').trim();
      if (!validId(tagId)) {
        return jsonRes({ error: 'Nieprawidłowy format Tag ID.' }, 400);
      }

      const data = await loadTag(env, tagId, true);
      if (!data) {
        return jsonRes({ error: 'Tag nie istnieje w bazie.' }, 404);
      }

      // Jesli ustawiono API_ADMIN_SECRET, tokeny/linki admina zwracamy tylko z naglowkiem X-Api-Admin.
      const adminOk = !env.API_ADMIN_SECRET || safeEqual(request.headers.get('X-Api-Admin'), env.API_ADMIN_SECRET);
      if (!adminOk && request.headers.get('X-Api-Admin')) registerFail(ip);
      return jsonRes({
        ok: true,
        tagId,
        status: data.status || 'active',
        claimPin: data.claimPin || null,
        ...(adminOk ? { token: data.token } : { adminLocked: true }),
        allowed: data.allowed || 'all',
        tagUrl: `${url.origin}/tag/${tagId}`,
        ...(adminOk ? { adminUrl: `${url.origin}/admin?tag=${encodeURIComponent(tagId)}&token=${encodeURIComponent(data.token)}` } : {})
      });
    }

    if (p === '/api/check-status') {
      if (isLocked(ip)) return jsonRes({ ok: false }, 429);
      const tagId = url.searchParams.get('tag') || '';
      const token = url.searchParams.get('token') || '';
      if (!validId(tagId) || !token) return jsonRes({ ok: false }, 400);
      const data = await loadTag(env, tagId, true);
      if (!data || !safeEqual(data.token, token)) { registerFail(ip); return jsonRes({ ok: false }, 403); }
      return jsonRes({
        ok: true,
        v: '7.8',
        pairedTg: Boolean(data.notifyTg),
        chatId: data.notifyTg || ''
      });
    }

    if (p.startsWith('/geo/') && request.method === 'POST') {
      const tagId = safeDecode(p.slice(5));
      if (!validId(tagId)) return new Response('not found', { status: 404 });
      const raw = await request.text();
      if (raw.length > 500) return new Response('bad', { status: 400 });
      const b = parse(raw) || {};
      if (!verifyGeoNonce(tagId, b.n)) return new Response('forbidden', { status: 403 });
      const isErr = b.err !== undefined;
      const kind = isErr ? 'geoerr' : 'geo';
      if (!hit(kind + 'ip:' + ip, 3000) || !hit(kind + ':' + tagId, isErr ? 60000 : 5000)) {
        return new Response('too many', { status: 429 });
      }
      const data = await loadTag(env, tagId, true);
      if (!data || !alertsOn(data, env)) {
        console.error('[geo] odrzucono – brak aktywnych powiadomień dla tagu', tagId);
        return new Response('not found', { status: 404 });
      }
      const headline = getScanHeadline(data, tagId).replace(/^[🔔🚨]\s*/u, '');

      if (isErr) {
        const why = {
          0: 'przeglądarka nie obsługuje geolokalizacji',
          1: 'brak zgody na lokalizację (odmowa lub GPS zablokowany w przeglądarce)',
          2: 'telefon nie mógł ustalić pozycji (brak sygnału GPS)',
          3: 'upłynął limit czasu pobierania pozycji'
        }[Number(b.err)] || 'nieznany błąd';
        console.log('[geo] błąd GPS u znalazcy:', tagId, b.err);
        ctx.waitUntil(deliver(env, data, 'Brak dokładnego GPS: ' + headline,
          'ℹ️ ' + headline + '\nNie udało się pobrać dokładnego GPS: ' + why + '.\nOrientacyjne miejsce masz w poprzedniej wiadomości.'));
        return new Response('ok');
      }

      const lat = Number(b.lat), lng = Number(b.lng), acc = Math.min(99999, Math.max(0, Math.round(Number(b.acc) || 0)));
      if (!Number.isFinite(lat) || !Number.isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180) {
        return new Response('bad', { status: 400 });
      }
      const text =
        '📍 Otrzymano dokładną lokalizację GPS dla: ' + headline + '\n' +
        'Dokładność: ok. ' + acc + ' m\n' +
        'Otwórz w mapach: https://maps.google.com/?q=' + lat.toFixed(6) + ',' + lng.toFixed(6);
      console.log('[geo] pozycja GPS:', tagId, 'acc', acc);
      ctx.waitUntil(deliver(env, data, 'Lokalizacja GPS: ' + headline, text));
      return new Response('ok');
    }

    if (p.startsWith('/tag/')) {
      const tagId = safeDecode(p.slice(5));
      if (!validId(tagId)) return new Response('Tag nie istnieje lub jest nieaktywny.', { status: 404 });

      if (isBot(request)) {
        return new Response('Brelok NFC ' + BRAND, {
          status: 200,
          headers: { 'Content-Type': 'text/plain;charset=UTF-8', 'Cache-Control': 'public, max-age=86400' }
        });
      }

      if (!rate('view:' + ip, 90, 60000)) return new Response('Zbyt wiele zapytań. Spróbuj za chwilę.', { status: 429 });
      const isPost = request.method === 'POST';
      const wantsPreview = url.searchParams.has('preview');
      const data = await loadTag(env, tagId, isPost || wantsPreview);
      if (!data) {
        if (!rate('miss:' + ip, 15, WINDOW)) return new Response('Zbyt wiele zapytań. Spróbuj za chwilę.', { status: 429 });
        return new Response('Tag nie istnieje lub jest nieaktywny.', { status: 404 });
      }
      if (data.status === 'deleted') return new Response('Ten brelok został dezaktywowany, a jego dane usunięte.', { status: 410, headers: { 'Cache-Control': 'no-store' } });

      if (data.status === 'unclaimed') {
        if (isPost) {
          if (isLocked(ip) || isLocked('tag:' + tagId)) {
            return new Response('Zbyt wiele błędnych prób. Spróbuj za chwilę.', { status: 429 });
          }
          const f = await request.formData().catch(() => null);
          const enteredPin = String(f?.get('pin') || '').trim();

          if (data.claimPin && safeEqual(enteredPin, data.claimPin)) {
            if (f.get('terms') !== '1') {
              return htmlRes(renderClaimScreen(tagId, 'Aby aktywować brelok, zaznacz oświadczenie o zapoznaniu się z Polityką Prywatności i ukończeniu 16 lat.'));
            }
            data.termsAt = new Date().toISOString();
            data.termsVer = POLICY_VER;
            data.status = 'active';
            delete data.claimPin;
            await env.REDIRECTS.put(tagId, JSON.stringify(data));
            return Response.redirect(`${url.origin}/admin?tag=${tagId}&token=${data.token}`, 303);
          }
          registerFail(ip, 'tag:' + tagId);
          return htmlRes(renderClaimScreen(tagId, 'Nieprawidłowy kod aktywacyjny PIN. Sprawdź kartonik dołączony do breloka.'));
        }
        return htmlRes(renderClaimScreen(tagId));
      }

      if (request.method !== 'GET' && request.method !== 'HEAD') return new Response('Method not allowed', { status: 405 });

      if (url.searchParams.get('vcard') === '1' && data.type === 'biz') {
        const c = (s) => String(s || '').replace(/[\r\n]+/g, ' ').replace(/([,;\\])/g, '\\$1');
        const nameParts = String(data.name || '').trim().split(/\s+/).filter(Boolean);
        const family = nameParts.length > 1 ? nameParts.pop() : '';
        const given = nameParts.join(' ');
        const vcard = [
          'BEGIN:VCARD', 'VERSION:3.0',
          `N:${c(family)};${c(given)};;;`,
          `FN:${c(data.name) || 'Kontakt'}`, `ORG:${c(data.company)}`, `TITLE:${c(data.title)}`,
          `TEL;TYPE=CELL:${c(telNum(data.phone))}`, `EMAIL:${c(data.email)}`, `URL:${c(data.web)}`,
          'END:VCARD'
        ].filter((l) => !/^(ORG|TITLE|TEL;TYPE=CELL|EMAIL|URL):$/.test(l)).join('\r\n') + '\r\n';
        const fname = (data.name || 'kontakt').replace(/[^\p{L}\p{N}_-]+/gu, '_');
        return new Response(vcard, {
          headers: {
            'Content-Type': 'text/vcard; charset=utf-8',
            'Content-Disposition': `attachment; filename="${fname}.vcf"`,
            'Cache-Control': 'public, max-age=300',
            'X-Content-Type-Options': 'nosniff'
          }
        });
      }

      const isPreview = safeEqual(url.searchParams.get('preview'), data.token);
      const alerts = alertsOn(data, env);
      if (alerts && !isPreview && hit('scan:' + tagId, 60000)) {
        ctx.waitUntil(notifyScan(env, tagId, data, request));
      }

      const currentUrl = url.origin + '/tag/' + encodeURIComponent(tagId);
      const publicCache = 'public, max-age=15, stale-while-revalidate=30';
      const respond = (html) => isPreview
        ? htmlRes(addPreviewBar(html, tagId, data.token, url.origin), 200, 'private, no-store')
        : htmlRes(html, 200, alerts ? 'private, no-store' : publicCache);

      switch (data.type) {
        case 'pet':  return respond(renderPet(data, tagId, isPreview, alerts));
        case 'lost': return respond(renderLost(data, tagId, isPreview, alerts));
        case 'ice':  return respond(renderIce(data, tagId, isPreview, alerts));
        case 'biz':  return respond(renderBiz(data, tagId, currentUrl));
        case 'wifi': return respond(renderWifi(data));
        case 'pay':  return respond(renderPay(data));
        case 'hub':  return respond(renderHub(data, hubLinks(data), currentUrl));
        case 'link': {
          const go = safeRedirect(data.url);
          return go || respond(renderNew());
        }
        default:
          return respond(renderNew());
      }
    }

    if (p === '/telegram-webhook' && request.method === 'POST') {
      if (!env.TELEGRAM_WEBHOOK_SECRET ||
          !safeEqual(request.headers.get('X-Telegram-Bot-Api-Secret-Token'), env.TELEGRAM_WEBHOOK_SECRET)) {
        console.error('Webhook Telegram: zły lub brakujący secret_token');
        return new Response('forbidden', { status: 403 });
      }
      try {
        const u = await request.json();
        const m = u.message;
        if (m && m.chat && env.TELEGRAM_TOKEN) {
          const text = (m.text || '').trim();
          const parts = text.split(/\s+/);
          const cmd = parts[0] || '';
          const payload = parts[1] || '';

          if (cmd.startsWith('/start') && payload) {
            await pairTag(env, m.chat.id, payload, url.origin);
          } else {
            await tgSend(env, m.chat.id,
              'Cześć! Twoje ID czatu to: ' + m.chat.id + '\n\n' +
              'Aby włączyć powiadomienia o skanach, otwórz panel breloka i kliknij "Połącz z Telegramem" lub wklej powyższe ID w sekcji powiadomień.');
          }
        }
      } catch (e) {
        console.error('Błąd webhooka:', e);
      }
      return new Response('ok');
    }

    if (p === '/admin') {
      if (isLocked(ip)) return new Response('Zbyt wiele prób. Spróbuj za kilka minut.', { status: 429 });
      const tagId = url.searchParams.get('tag') || '';
      const token = url.searchParams.get('token') || '';
      if (!validId(tagId) || !token) { registerFail(ip); return new Response('Brak tagu lub tokenu autoryzacji.', { status: 400 }); }

      const data = await loadTag(env, tagId, true);
      if (!data) { registerFail(ip); return new Response('Tag nie istnieje w bazie.', { status: 404 }); }
      if (data.status === 'deleted') return new Response('Tag nie istnieje w bazie.', { status: 404 });
      if (!safeEqual(data.token, token)) { registerFail(ip); return new Response('Brak autoryzacji.', { status: 403 }); }

      const cleanAdminUrl = `${url.origin}/admin?tag=${encodeURIComponent(tagId)}&token=${encodeURIComponent(token)}`;

      if (request.method === 'GET' && url.searchParams.get('export') === '1') {
        const out = { exportedAt: new Date().toISOString(), tagId };
        for (const [k, v] of Object.entries(data)) if (k !== 'token' && k !== 'claimPin') out[k] = v;
        return new Response(JSON.stringify(out, null, 2), { headers: {
          'Content-Type': 'application/json; charset=utf-8',
          'Content-Disposition': `attachment; filename="tapcraft-${tagId}-dane.json"`,
          'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' } });
      }

      if (request.method === 'POST') {
        const site = request.headers.get('Sec-Fetch-Site');
        const origin = request.headers.get('Origin');
        const foreign = site
          ? !(site === 'same-origin' || site === 'none')
          : Boolean(origin && origin !== 'null' && origin !== url.origin);
        if (foreign) return new Response('Niedozwolone źródło.', { status: 403 });
        if (Number(request.headers.get('content-length') || 0) > 30000) {
          return new Response('Za duże żądanie.', { status: 413 });
        }
        const f = await request.formData();
        const g = (k) => (f.get(k)?.toString().trim() || '').slice(0, 600);

        if (f.get('erase') === '1') {
          const conf = String(f.get('eraseConfirm') || '').trim().toUpperCase();
          if (conf !== 'USUŃ' && conf !== 'USUN') return errPage('Aby trwale usunąć dane, wpisz słowo USUŃ w polu potwierdzenia (w „Więcej opcji").');
          await env.REDIRECTS.put(tagId, JSON.stringify({ token: crypto.randomUUID(), status: 'deleted', deletedAt: new Date().toISOString(), createdAt: data.createdAt || '' }));
          return simplePage('Dane usunięte', 'Wszystkie dane z tego breloka zostały trwale usunięte, a brelok dezaktywowany. Zniknie też z kopii zapasowych w ciągu 30 dni.', 200);
        }

        const rotated = f.get('rotate') === '1';
        const updated = { token: rotated ? crypto.randomUUID() : data.token, createdAt: data.createdAt || '', status: 'active' };
        for (const k of FIELDS) updated[k] = g(k);
        const allowedList = Array.isArray(data.allowed) && data.allowed.length ? data.allowed : MODES;
        if (Array.isArray(data.allowed)) updated.allowed = data.allowed;
        const mode = g('mode');
        updated.type = allowedList.includes(mode) ? mode
          : allowedList.includes(data.type) ? data.type
          : allowedList.length === 1 ? allowedList[0] : 'new';
        updated.security = g('security') === 'nopass' ? 'nopass' : 'WPA';
        if (!STYLE_KEYS.includes(updated.theme)) updated.theme = '';
        updated.notifyActive = f.get('notifyActive') === '1' ? '1' : '0';

        const unlinkTg = f.get('unlinkTg') === '1';
        const manualTg = g('notifyTg').replace(/[^\d-]/g, '');

        if (unlinkTg) {
          updated.notifyTg = '';
        } else if (manualTg) {
          updated.notifyTg = manualTg;
        } else {
          updated.notifyTg = data.notifyTg || '';
        }

        updated.notifyEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(g('notifyEmail')) ? g('notifyEmail') : '';
        // --- RODO: minimalizacja, oswiadczenie, zgoda na dane zdrowotne ---
        const nowIso = new Date().toISOString();
        if (updated.type !== 'ice') { updated.blood = ''; updated.allergies = ''; }
        if (!data.termsAt && f.get('terms') !== '1') return errPage('Zaznacz oświadczenie o zapoznaniu się z Polityką Prywatności (i ukończeniu 16 lat), aby zapisać zmiany.');
        updated.termsAt = data.termsAt || nowIso;
        updated.termsVer = data.termsVer || POLICY_VER;
        if (updated.blood || updated.allergies) {
          if (f.get('healthConsent') !== '1') return errPage('Dane o zdrowiu (grupa krwi, alergie, leki) wymagają Twojej wyraźnej zgody. Zaznacz zgodę w sekcji karty ICE albo usuń te pola.');
          updated.healthConsentAt = (data.healthConsentAt && data.healthConsentVer === POLICY_VER) ? data.healthConsentAt : nowIso;
          updated.healthConsentVer = POLICY_VER;
        } else { updated.healthConsentAt = ''; updated.healthConsentVer = ''; }
        await env.REDIRECTS.put(tagId, JSON.stringify(updated));

        if (g('after') === 'preview') {
          return Response.redirect(`${url.origin}/tag/${encodeURIComponent(tagId)}?preview=${encodeURIComponent(updated.token)}`, 303);
        }
        const newAdminUrl = `${url.origin}/admin?tag=${encodeURIComponent(tagId)}&token=${encodeURIComponent(updated.token)}`;
        return Response.redirect(`${newAdminUrl}&saved=1${rotated ? '&rotated=1' : ''}`, 303);
      }

      const tgFromUrl = url.searchParams.get('tg_paired');
      if (tgFromUrl && /^-?\d+$/.test(tgFromUrl)) {
        data.notifyTg = tgFromUrl;
        data.notifyActive = '1';
        ctx.waitUntil(env.REDIRECTS.put(tagId, JSON.stringify(data)));
      }

      const caps = {
        tg: Boolean(env.TELEGRAM_TOKEN),
        mail: Boolean(env.RESEND_API_KEY && env.MAIL_FROM),
        bot: (env.TELEGRAM_BOT_NAME || '').replace(/^@/, '')
      };
      caps.pairUrl = await pairUrlFor(env, tagId);
      const isSaved = url.searchParams.get('saved') === '1';
      const isRotated = url.searchParams.get('rotated') === '1';
      return htmlRes(renderAdmin(tagId, token, data, isRotated ? 'Zapisano! To jest Twój NOWY link do panelu — zapisz go. Stary link przestał działać.' : isSaved ? 'Zapisano! Twoje dane są już na breloku.' : '', caps, cleanAdminUrl));
    }

    return new Response('System ' + BRAND + ' działa.', { status: 200 });
  }
};

const FIELDS = [
  'petName', 'petPhone', 'petCity', 'petNotes',
  'iceName', 'blood', 'icePhone', 'allergies',
  'name', 'company', 'title', 'phone', 'email', 'web', 'bio',
  'lostItem', 'lostPhone', 'reward',
  'ssid', 'password',
  'theme',
  'hubName', 'hubBio', 'google', 'instagram', 'tiktok', 'facebook', 'youtube', 'whatsapp', 'hubWeb',
  'pName', 'pPurpose', 'pAmount', 'pBlik', 'pRevolut', 'pPaypal', 'pIban',
  'url'
];

async function tgSend(env, chatId, text) {
  try {
    const r = await fetch(`https://api.telegram.org/bot${env.TELEGRAM_TOKEN}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: chatId, text })
    });
    if (!r.ok) console.error('Telegram sendMessage:', r.status, await r.text());
  } catch (e) {
    console.error('Telegram sendMessage błąd:', e);
  }
}

async function hmac16(secret, msg) {
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey(
    'raw', enc.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']
  );
  const sig = new Uint8Array(await crypto.subtle.sign('HMAC', key, enc.encode(msg)));
  return Array.from(sig.slice(0, 8), (b) => b.toString(16).padStart(2, '0')).join('');
}

async function pairUrlFor(env, tagId) {
  const botName = (env.TELEGRAM_BOT_NAME || '').replace(/^@/, '');
  if (!env.TELEGRAM_TOKEN || !botName || !env.TELEGRAM_WEBHOOK_SECRET || tagId.length > 47) return '';
  const sig = await hmac16(env.TELEGRAM_WEBHOOK_SECRET, 'pair:' + tagId);
  return `https://t.me/${botName}?start=${tagId}p${sig}`;
}

async function pairTag(env, chatId, payload, origin) {
  const fail = () => tgSend(env, chatId, 'Link parowania jest nieprawidłowy lub wygasł. Kliknij ponownie przycisk w panelu breloka.');
  try {
    if (!env.TELEGRAM_WEBHOOK_SECRET) return fail();
    const cut = payload.lastIndexOf('p');
    if (cut < 1) return fail();

    const tagId = payload.slice(0, cut);
    const sig = payload.slice(cut + 1).toLowerCase();
    const expectedSig = (await hmac16(env.TELEGRAM_WEBHOOK_SECRET, 'pair:' + tagId)).toLowerCase();

    if (!validId(tagId) || !safeEqual(sig, expectedSig)) return fail();

    const data = await loadTag(env, tagId, true);
    if (!data) return fail();

    data.notifyTg = String(chatId);
    data.notifyActive = '1';
    await env.REDIRECTS.put(tagId, JSON.stringify(data));

    const label = getPairLabel(data);
    const host = origin || env.BASE_URL;
    const returnUrl = `${host}/admin?tag=${encodeURIComponent(tagId)}&token=${encodeURIComponent(data.token)}&tg_paired=${chatId}`;

    const msg = `✅ Połączono! Będziesz dostawać powiadomienia o skanach:\n${label}\n\n` +
      `Twoje ID czatu: ${chatId}\n\n` +
      `Kliknij przycisk poniżej, aby wrócić do panelu:`;

    const r = await fetch(`https://api.telegram.org/bot${env.TELEGRAM_TOKEN}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        text: msg,
        reply_markup: {
          inline_keyboard: [[
            { text: "⬅️ Wróć do panelu breloka", url: returnUrl }
          ]]
        }
      })
    });
    if (!r.ok) {
      console.error('Telegram odrzucił wiadomość z przyciskiem:', r.status, await r.text());
      await tgSend(env, chatId, msg.replace('Kliknij przycisk poniżej, aby wrócić do panelu:', 'Wróć do panelu breloka i odśwież stronę.'));
    }
  } catch (err) {
    console.error('Błąd w pairTag:', err);
    await tgSend(env, chatId, 'Błąd serwera. Spróbuj ponownie.');
  }
}

async function deliver(env, data, subject, text) {
  const jobs = [];
  if (data.notifyTg && env.TELEGRAM_TOKEN) jobs.push(tgSend(env, data.notifyTg, text));
  if (data.notifyEmail && env.RESEND_API_KEY && env.MAIL_FROM) {
    jobs.push(fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { 'Authorization': 'Bearer ' + env.RESEND_API_KEY, 'Content-Type': 'application/json' },
      body: JSON.stringify({ from: env.MAIL_FROM, to: [data.notifyEmail], subject, text })
    }));
  }
  await Promise.allSettled(jobs);
}

async function notifyScan(env, tagId, data, request) {
  try {
    const place = await geoPlace(request.headers.get('cf-connecting-ip') || request.headers.get('x-forwarded-for') || '');
    const time = new Date().toLocaleString('pl-PL', { timeZone: 'Europe/Warsaw' });
    const headline = getScanHeadline(data, tagId);
    const text =
      headline + '\n\n' +
      'Gdzie: ' + place + ' (orientacyjnie na podstawie masztu / sieci)\n' +
      'Kiedy: ' + time;
    await deliver(env, data, headline.replace(/^[🔔🚨]\s*/u, ''), text);
  } catch (e) {}
}

const P = {
  phone: '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>',
  mail: '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/>',
  globe: '<circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15 15 0 0 1 0 20M12 2a15 15 0 0 0 0 20"/>',
  addUser: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M19 8v6M22 11h-6"/>',
  sms: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
  pin: '<path d="M21 10c0 7-9 13-9 13S3 17 3 10a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/>',
  copy: '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
  eye: '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12z"/><circle cx="12" cy="12" r="3"/>',
  wifi: '<path d="M5 12.55a11 11 0 0 1 14.08 0M1.42 9a16 16 0 0 1 21.16 0M8.53 16.11a6 6 0 0 1 6.95 0"/><circle cx="12" cy="20" r="1"/>',
  key: '<circle cx="7.5" cy="15.5" r="5.5"/><path d="m21 2-9.6 9.6M15.5 7.5l3 3L22 7l-3-3"/>',
  cross: '<path d="M12 4v16M4 12h16"/>',
  alert: '<path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><path d="M12 9v4M12 17h.01"/>',
  instagram: '<rect x="2" y="2" width="20" height="20" rx="5"/><circle cx="12" cy="12" r="4"/><path d="M17.5 6.5h.01"/>',
  facebook: '<path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/>',
  youtube: '<path d="M22.54 6.42a2.78 2.78 0 0 0-1.94-2C18.88 4 12 4 12 4s-6.88 0-8.6.46a2.78 2.78 0 0 0-1.94 2A29 29 0 0 0 1 11.75a29 29 0 0 0 .46 5.33A2.78 2.78 0 0 0 3.4 19c1.72.46 8.6.46 8.6.46s6.88 0 8.6-.46a2.78 2.78 0 0 0 1.94-2 29 29 0 0 0 .46-5.25 29 29 0 0 0-.46-5.33z"/><path d="m9.75 15.02 5.75-3.27-5.75-3.27z"/>',
  tiktok: '<path d="M9 12a4 4 0 1 0 4 4V3c.5 2.5 2.5 4 5 4"/>',
  star: '<path d="m12 2 3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01z"/>',
  card: '<rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20"/>',
  paw: '<circle cx="5" cy="11" r="2"/><circle cx="10" cy="6" r="2"/><circle cx="16" cy="6" r="2"/><circle cx="21" cy="11" r="2"/><path d="M12.5 12c-3 0-6 3.2-6 5.6 0 1.7 1.3 2.6 3 2.6 1.3 0 2-.7 3-.7s1.7.7 3 .7c1.7 0 3-.9 3-2.6 0-2.4-3-5.6-6-5.6z"/>',
  link: '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>',
  qr: '<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><path d="M14 14h3v3M21 14v.01M14 21h.01M17 21h4v-4"/>',
  bookmark: '<path d="m19 21-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>',
  shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
  scissors: '<circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M20 4 8.12 15.88M14.47 14.48 20 20M8.12 8.12 12 12"/>',
  wrench: '<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>',
  car: '<path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2"/><circle cx="7" cy="17" r="2"/><path d="M9 17h6"/><circle cx="17" cy="17" r="2"/>',
  briefcase: '<rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/>',
  sparkles: '<path d="M9.94 15.5A2 2 0 0 0 8.5 14.06l-6.13-1.58a.5.5 0 0 1 0-.96L8.5 9.94A2 2 0 0 0 9.94 8.5l1.58-6.13a.5.5 0 0 1 .96 0l1.58 6.13a2 2 0 0 0 1.44 1.44l6.13 1.58a.5.5 0 0 1 0 .96l-6.13 1.58a2 2 0 0 0-1.44 1.44l-1.58 6.13a.5.5 0 0 1-.96 0z"/><path d="M20 3v4M22 5h-4M4 17v2M5 18H3"/>',
  dumbbell: '<path d="M6.5 6.5v11M17.5 6.5v11M3.5 9v6M20.5 9v6M6.5 12h11"/>',
  coffee: '<path d="M10 2v2M14 2v2M6 2v2"/><path d="M16 8a1 1 0 0 1 1 1v8a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4V9a1 1 0 0 1 1-1h14a4 4 0 1 1 0 8h-1"/>'
};

const ic = (name, size = 20) =>
  `<svg class="ic" width="${size}" height="${size}" viewBox="0 0 24 24" aria-hidden="true">${P[name] || ''}</svg>`;

const PAW = (size = 64) => `<svg width="${size}" height="${size}" viewBox="0 0 28 24" fill="currentColor" aria-hidden="true"><ellipse cx="5" cy="10" rx="2.3" ry="3"/><ellipse cx="10.5" cy="5" rx="2.3" ry="3"/><ellipse cx="17.5" cy="5" rx="2.3" ry="3"/><ellipse cx="23" cy="10" rx="2.3" ry="3"/><path d="M14 11c-4 0-8 4.2-8 7.5 0 2.2 1.7 3.5 4 3.5 1.7 0 2.6-.9 4-.9s2.3.9 4 .9c2.3 0 4-1.3 4-3.5C22 15.2 18 11 14 11z"/></svg>`;

const baseCss = `
  *{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
  html,body{margin:0}
  body{min-height:100vh;min-height:100dvh;font-family:'Manrope',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;-webkit-font-smoothing:antialiased;display:flex;justify-content:center}
  .ic{fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;flex:none}
  .btn{display:flex;align-items:center;justify-content:center;gap:10px;width:100%;padding:17px 18px;border-radius:14px;font:700 16px/1.2 inherit;font-family:inherit;border:0;text-decoration:none;cursor:pointer;transition:transform .1s ease}
  .btn:active{transform:scale(.98)}
  .btn:focus-visible,a:focus-visible,button:focus-visible{outline:3px solid #38bdf8;outline-offset:2px}
  .stack{display:grid;gap:10px}
  .qrbtn{display:flex;align-items:center;justify-content:center;gap:8px;margin:20px auto 0;padding:10px 14px;background:none;border:0;color:inherit;opacity:.7;font:600 14px/1 inherit;font-family:inherit;cursor:pointer}
  #qrModal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.72);place-items:center;z-index:99;padding:20px}
  #qrModal .box{background:#fff;color:#111;padding:24px;border-radius:20px;text-align:center;max-width:280px}
  #qrModal .box p{margin:12px 0 0;font-size:13px;font-weight:600;color:#475569}
  #tagQr{display:grid;justify-items:center;min-height:176px}
  .legal-foot{margin-top:28px;text-align:center;font-size:12px;opacity:.65}
  .legal-foot a{color:inherit;text-decoration:underline}
`;

const fonts = (_font) => '';

function shell({ title, theme, font, css, body, script = '' }) {
  return `<!DOCTYPE html>
<html lang="pl"><head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="${theme}">
<meta name="robots" content="noindex">
<link rel="icon" href="data:,">
<title>${esc(title)}</title>
${fonts(font)}
<style>${baseCss}${css}</style>
</head><body>${body}${script ? `<script>${script}</script>` : ''}</body></html>`;
}

function renderClaimScreen(tagId, err = '') {
  const css = `
    body{background:#0b1329;color:#fff;align-items:center;padding:24px 18px;background-image:radial-gradient(circle at 50% -20%,#1e3a8a 0,#0b1329 70%)}
    .card{width:100%;max-width:390px;text-align:center}
    .tag-badge{display:inline-block;padding:5px 12px;border-radius:999px;background:#111c38;border:1px solid #1e293b;color:#94a3b8;font-size:12px;font-weight:700;letter-spacing:.5px;font-family:'JetBrains Mono',monospace;margin:0 0 14px}
    h1{font-size:26px;margin:0 0 8px;font-weight:800}
    p{margin:0 0 20px;color:#94a3b8;font-size:15px;line-height:1.55}
    .form-box{background:#111c38;border:1px solid #1e293b;border-radius:20px;padding:22px 18px;box-shadow:0 20px 40px rgba(0,0,0,.4)}
    label{display:block;font-size:13px;font-weight:700;color:#cbd5e1;margin-bottom:8px;text-align:left}
    input{width:100%;padding:14px;background:#090d1a;border:2px solid #334155;border-radius:12px;color:#fff;font-size:24px;font-weight:700;text-align:center;letter-spacing:6px;outline:none;font-family:'JetBrains Mono',monospace;margin-bottom:18px}
    input:focus{border-color:#38bdf8}
    .btn-act{background:#38bdf8;color:#0b1329;font-weight:800;font-size:16px}
    .err{background:#ef444422;border:1px solid #ef444488;color:#fca5a5;padding:10px 14px;border-radius:12px;font-size:13px;margin-bottom:16px;text-align:left;line-height:1.4}
    .support-hint{margin-top:16px;font-size:12px;color:#64748b;line-height:1.4}
    .chk{display:flex;gap:10px;align-items:flex-start;text-align:left;font-size:13px;font-weight:500;color:#cbd5e1;line-height:1.45;margin:0 0 16px;cursor:pointer}
    .chk input{width:18px;height:18px;margin:2px 0 0;padding:0;flex:none;letter-spacing:0;font-size:14px}
  `;
  const body = `
  <main class="card">
    ${LOGO_PIONOWE_CIEMNE}
    <div class="tag-badge">BRELOK #${esc(tagId)}</div>
    <h1>Aktywuj swój brelok</h1>
    <p>Witaj w ${BRAND}! Przypisz ten brelok do siebie, aby nadać mu wybraną funkcję i chronić swoje dane.</p>
    <div class="form-box">
      ${err ? `<div class="err">${esc(err)}</div>` : ''}
      <form method="POST">
        <label>Podaj 6-cyfrowy kod PIN:</label>
        <input type="text" inputmode="numeric" name="pin" placeholder="••••••" maxlength="6" autofocus required>
        <label class="chk"><input type="checkbox" name="terms" value="1" required><span>Mam ukończone 16 lat i zapoznałem/am się z <a href="/privacy" target="_blank" style="color:#38bdf8">Polityką Prywatności</a>${process.env.TERMS_URL ? ` oraz <a href="${esc(process.env.TERMS_URL)}" target="_blank" style="color:#38bdf8">Regulaminem</a>` : ''}.</span></label>
        <button type="submit" class="btn btn-act">Aktywuj i przejdź do panelu</button>
      </form>
      <div class="support-hint">
        Nie masz kodu? Skontaktuj się ze wsparciem i podaj identyfikator <b>#${esc(tagId)}</b>.
      </div>
    </div>
    <div class="legal-foot"><a href="/privacy">Polityka prywatności</a></div>
  </main>`;
  return shell({
    title: 'Aktywacja breloka ' + BRAND + ' #' + tagId,
    theme: '#0b1329',
    font: 'Manrope:wght@500;700;800&family=JetBrains+Mono:wght@700',
    css,
    body
  });
}

const qrLoader = `
  function loadQr(cb){
    if(window.QRCode) return cb();
    var s=document.createElement('script');
    s.src='https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js';
    s.onload=cb; document.head.appendChild(s);
  }`;
const qrShare = `
  <button type="button" class="qrbtn" onclick="openQr()">${ic('qr', 18)}Pokaż kod QR do udostępnienia</button>
  <div id="qrModal" onclick="closeQr()"><div class="box" onclick="event.stopPropagation()">
    <div id="tagQr"></div><p>Zeskanuj aparatem telefonu</p></div></div>`;
const qrScript = (tagUrl) => qrLoader + `
  function openQr(){
    document.getElementById('qrModal').style.display='grid';
    if(!window.__qr){ loadQr(function(){ new QRCode(document.getElementById('tagQr'),{text:${jsonForScript(tagUrl)},width:176,height:176}); window.__qr=1; }); }
  }
  function closeQr(){ document.getElementById('qrModal').style.display='none'; }`;

function locationBlock(cls, alerts, phone) {
  if (!alerts && !phone) return '';
  const label = 'Wyślij właścicielowi moją lokalizację GPS';
  return `<button class="btn ${cls}" onclick="sendLoc(this)">${ic('pin')}<span>${label}</span></button>
  <p style="margin:8px 0 0;font-size:11.5px;line-height:1.45;opacity:.7;text-align:center">Pozycja GPS trafi tylko do właściciela, po Twojej zgodzie w przeglądarce, i nie jest nigdzie zapisywana. <a href="/privacy" style="color:inherit;text-decoration:underline">Szczegóły</a></p>`;
}

const locationScript = ({ phone, text, tagId, alerts, preview }) => `
  var PH=${jsonForScript(telNum(phone))}, TX=${jsonForScript(text)}, ID=${jsonForScript(tagId)}, GN=${jsonForScript(geoNonce(tagId))}, ALERT=${alerts ? 'true' : 'false'}, PREVIEW=${preview ? 'true' : 'false'};
  function postGeo(lat, lng, acc, onOk, onErr){
    fetch('/geo/'+encodeURIComponent(ID),{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({lat:lat,lng:lng,acc:acc,n:GN})
    }).then(function(r){
      if(r.ok || r.status===429){ if(onOk) onOk(); }
      else { if(onErr) onErr(); }
    }).catch(function(){ if(onErr) onErr(); });
  }
  function getPos(ok, fail){
    if(!navigator.geolocation){ fail({code:0}); return; }
    navigator.geolocation.getCurrentPosition(ok, function(err){
      if(err && err.code===1){ fail(err); return; }
      navigator.geolocation.getCurrentPosition(ok, fail, {enableHighAccuracy:false,timeout:15000,maximumAge:120000});
    }, {enableHighAccuracy:true,timeout:10000,maximumAge:0});
  }
  function sendLoc(btn){
    var label=btn.querySelector('span'), old=label.textContent;
    function back(m){ label.textContent=m; setTimeout(function(){ label.textContent=old; },3000); }
    function sms(lat,lng){
      if(!PH){ back('Brak numeru SMS'); return; }
      location.href='sms:'+PH+'?&body='+encodeURIComponent(TX+(lat?' Jestem tutaj: https://maps.google.com/?q='+lat+','+lng:''));
    }
    if(PREVIEW){ back('To tylko podgląd (geolokalizacja wyłączona)'); return; }
    if(!navigator.geolocation){
      if(PH) sms(); else back('Brak modułu GPS');
      return;
    }
    label.textContent='Pobieram pozycję GPS…';
    getPos(function(p){
      var lat=p.coords.latitude, lng=p.coords.longitude, acc=Math.round(p.coords.accuracy||0);
      if(!ALERT && PH){ label.textContent=old; sms(lat,lng); return; }
      label.textContent='Wysyłam do właściciela…';
      postGeo(lat, lng, acc, function(){
        btn.disabled=true;
        label.textContent='✓ Wysłano właścicielowi. Dziękujemy!';
      }, function(){
        if(PH) sms(lat,lng); else back('Błąd serwera. Spróbuj za chwilę');
      });
    }, function(err){
      if(err.code === 1){
        back('Brak zgody na GPS w telefonie');
      } else if(err.code === 2){
        back('Nie można ustalić pozycji GPS');
      } else {
        back('Upłynął limit czasu GPS');
      }
    });
  }`;

function simplePage(title, msg, status = 400) {
  const css = `body{background:#f8fafc;color:#1e293b;align-items:flex-start;padding:32px 18px}
    .box{max-width:480px;background:#fff;border-radius:16px;padding:26px 22px;box-shadow:0 4px 20px rgba(0,0,0,.06)}
    h1{font-size:20px;margin:0 0 12px;color:#0f172a} p{font-size:15px;line-height:1.6;color:#475569;margin:0 0 14px} a{color:#0284c7}`;
  const body = `<main class="box"><h1>${esc(title)}</h1><p>${esc(msg)}</p><p><a href="javascript:history.back()">← Wróć i popraw</a></p></main>`;
  return htmlRes(shell({ title, theme: '#f8fafc', font: '', css, body }), status, 'no-store');
}
const errPage = (msg) => simplePage('Nie zapisano', msg, 400);

function renderPrivacy(host, env = {}) {
  const css = `
    body{background:#f8fafc;color:#1e293b;align-items:flex-start;padding:32px 18px 60px}
    .box{max-width:580px;background:#fff;border-radius:20px;padding:30px 24px;box-shadow:0 4px 20px rgba(0,0,0,.06)}
    h1{font-size:24px;margin:0 0 16px;color:#0f172a}
    h2{font-size:17px;margin:20px 0 8px;color:#0f172a}
    p,li{font-size:14px;line-height:1.65;color:#475569}
    ul{padding-left:20px;margin:6px 0}
    a{color:#0284c7;text-decoration:none}
  `;
  const admin = esc(env.LEGAL_NAME || '[uzupełnij: imię i nazwisko / nazwa firmy, adres]') + (env.LEGAL_ID ? ', ' + esc(env.LEGAL_ID) : '');
  const mail = esc(env.CONTACT_EMAIL || '[uzupełnij: e-mail kontaktowy]');
  const geo = GEO_PROVIDER === 'off'
    ? 'Nie wysyłamy adresów IP do zewnętrznych usług geolokalizacji - w powiadomieniach nie podajemy miasta.'
    : `Do ustalenia przybliżonego miasta i kraju skanu adres IP jest jednorazowo sprawdzany w zewnętrznej usłudze (${GEO_PROVIDER === 'ipapi' ? 'ip-api.com' : 'ipwho.is'}); wynik jest przechowywany w pamięci serwera nie dłużej niż 1 godzinę.`;
  const body = `
  <main class="box">
    <h1>Polityka Prywatności</h1>
    <p>Dotyczy usługi inteligentnych breloków NFC ${esc(BRAND)} (serwis ${esc(host)}). Wersja z dnia ${esc(POLICY_VER)}.</p>

    <h2>1. Administrator danych</h2>
    <p>${admin}. Kontakt w sprawach danych osobowych: ${mail}.</p>

    <h2>2. Jakie dane, po co i na jakiej podstawie</h2>
    <ul>
      <li><strong>Dane właściciela breloka</strong> - treści wpisane w panelu (np. imię zwierzaka, numer telefonu, dane wizytówki, hasło Wi-Fi, dane do płatności), identyfikator breloka, token dostępu, a przy powiadomieniach: identyfikator czatu Telegram lub adres e-mail. Cel: świadczenie usługi breloka, w tym publiczne wyświetlanie wpisanych treści po zeskanowaniu. Podstawa: wykonanie umowy (art. 6 ust. 1 lit. b RODO).</li>
      <li><strong>Dane o zdrowiu w karcie ICE</strong> (grupa krwi, alergie, choroby, leki) - tylko za Twoją wyraźną zgodą (art. 9 ust. 2 lit. a RODO) zaznaczoną w panelu. Są <strong>publicznie widoczne</strong> dla każdego, kto zeskanuje brelok lub pozna jego adres. Zgodę możesz wycofać w każdej chwili, usuwając te dane w panelu lub kasując cały brelok; nie wpływa to na zgodność z prawem wcześniejszego przetwarzania. Podanie tych danych jest dobrowolne.</li>
      <li><strong>Data akceptacji oświadczenia i zgody</strong> - przechowujemy ją, aby wykazać, że zgoda została udzielona (art. 6 ust. 1 lit. c i f RODO).</li>
      <li><strong>Osoba skanująca brelok:</strong> (a) adres IP przetwarzany chwilowo w pamięci serwera na potrzeby limitów zapytań i ochrony przed nadużyciami (art. 6 ust. 1 lit. f); (b) jeśli właściciel włączył powiadomienia - czas skanu i przybliżone miasto wysyłane właścicielowi (art. 6 ust. 1 lit. f - interes właściciela w odzyskaniu rzeczy lub zwierzęcia); (c) dokładna pozycja GPS - tylko jeśli sama klikniesz przycisk i zgodzisz się w przeglądarce (art. 6 ust. 1 lit. a); trafia wyłącznie do właściciela i nie jest zapisywana w naszej bazie.</li>
    </ul>

    <h2>3. Odbiorcy danych</h2>
    <ul>
      <li>Dostawca serwera VPS i usługi publikacji (mikr.us / Cytrus) - hosting bazy danych.</li>
      <li>Telegram i Resend - tylko jeśli właściciel włączył powiadomienia (Telegram: wiadomości; Resend: e-maile).</li>
      <li>Dostawca zaszyfrowanych kopii zapasowych bazy danych (przechowywanie zaszyfrowanych plików).</li>
      <li>${geo}</li>
      <li>Dane nie są sprzedawane ani używane do marketingu. Treści wpisane przez właściciela widzi każdy, kto zeskanuje brelok.</li>
    </ul>
    <p>Dostawcy mogą przetwarzać dane poza Europejskim Obszarem Gospodarczym; przekazanie odbywa się na podstawie mechanizmów z rozdziału V RODO (np. decyzja o odpowiednim stopniu ochrony lub standardowe klauzule umowne).</p>

    <h2>4. Jak długo przechowujemy dane</h2>
    <p>Do czasu usunięcia danych przez właściciela (przycisk w panelu) lub dezaktywacji breloka; po usunięciu pozostaje wyłącznie pusty wpis techniczny bez danych osobowych. Kopie zapasowe bazy są przechowywane maksymalnie 30 dni, po czym usunięte dane znikają także z nich. Adresy IP nie są zapisywane w bazie.</p>

    <h2>5. Twoje prawa</h2>
    <p>Masz prawo dostępu do danych, ich sprostowania, usunięcia, ograniczenia przetwarzania, przenoszenia, sprzeciwu wobec przetwarzania opartego na prawnie uzasadnionym interesie oraz wycofania zgody. W panelu breloka (sekcja „Więcej opcji") możesz samodzielnie <strong>pobrać swoje dane (JSON)</strong> i <strong>trwale je usunąć</strong>. W pozostałych sprawach napisz: ${mail}. Masz też prawo wniesienia skargi do Prezesa Urzędu Ochrony Danych Osobowych (ul. Stawki 2, 00-193 Warszawa).</p>

    <h2>6. Bezpieczeństwo</h2>
    <p>Połączenia są szyfrowane (HTTPS), dostęp do panelu chroni tajny link, aktywację - kod PIN z ograniczeniem liczby prób, a kopie zapasowe są szyfrowane. Nie ma zautomatyzowanego podejmowania decyzji ani profilowania. Nie używamy cookies, narzędzi analitycznych ani zewnętrznych czcionek.</p>

    <h2>7. Ważne</h2>
    <ul>
      <li>Z usługi mogą korzystać osoby, które ukończyły 16 lat.</li>
      <li>Wpisując dane innej osoby (np. kontakt ratunkowy), oświadczasz, że masz do tego podstawę i poinformowałeś/aś ją o tym.</li>
      <li>Dane ICE wpisuje właściciel; mogą być nieaktualne i nie zastępują dokumentacji medycznej ani 112.</li>
    </ul>

    <p style="margin-top:24px"><a href="javascript:history.back()">← Powrót do poprzedniej strony</a></p>
  </main>`;
  return shell({ title: 'Polityka Prywatności', theme: '#f8fafc', font: '', css, body });
}

function renderNew() {
  const css = `
    body{background:#0f172a;color:#fff;align-items:center;padding:24px 18px}
    .card{width:100%;max-width:380px;text-align:center}
    h1{font-size:26px;margin:0 0 10px;font-weight:800}
    p{margin:0;color:#94a3b8;font-size:16px;line-height:1.6}
  `;
  const body = `<main class="card">
    ${LOGO_PIONOWE_CIEMNE}
    <h1>Ten brelok czeka na ustawienie</h1>
    <p>Otwórz link administracyjny otrzymany przy zakupie, aby nadać mu wybraną funkcję.</p>
    <div class="legal-foot"><a href="/privacy">Polityka prywatności</a></div></main>`;
  return shell({ title: 'Brelok NFC ' + BRAND, theme: '#0f172a', font: 'Manrope:wght@500;800', css, body });
}

function renderPet(d, tagId, isPreview, alerts) {
  const name = d.petName || 'Zwierzak';
  const paws = encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="120" height="120" viewBox="0 0 120 120"><g fill="#f59e0b" fill-opacity=".13" transform="translate(18 20) rotate(-18) scale(1.5)"><ellipse cx="5" cy="10" rx="2.3" ry="3"/><ellipse cx="10.5" cy="5" rx="2.3" ry="3"/><ellipse cx="17.5" cy="5" rx="2.3" ry="3"/><ellipse cx="23" cy="10" rx="2.3" ry="3"/><path d="M14 11c-4 0-8 4.2-8 7.5 0 2.2 1.7 3.5 4 3.5 1.7 0 2.6-.9 4-.9s2.3.9 4 .9c2.3 0 4-1.3 4-3.5C22 15.2 18 11 14 11z"/></g></svg>`);
  const css = `
    body{background:#fff4dc url("data:image/svg+xml,${paws}");font-family:'Fredoka','Manrope',sans-serif;color:#3b2a14;align-items:center;padding:20px 16px}
    .card{width:100%;max-width:400px;background:#fff;border-radius:32px;padding:0 24px 28px;box-shadow:0 20px 40px -18px rgba(120,70,0,.35);text-align:center;overflow:hidden}
    .badge{margin:0 -24px;background:#ef4444;color:#fff;padding:13px 16px;font-weight:600;font-size:15px;display:flex;gap:8px;align-items:center;justify-content:center}
    .avatar{width:112px;height:112px;margin:28px auto 16px;border-radius:50%;background:#fde68a;color:#b45309;display:grid;place-items:center;border:5px solid #fff;box-shadow:0 0 0 4px #f59e0b}
    h1{font-size:34px;line-height:1.1;margin:0 0 8px;font-weight:600}
    .lead{margin:0 0 24px;font-size:17px;line-height:1.45;color:#7c5a2e;font-family:'Manrope',sans-serif;font-weight:500}
    .call{background:#16a34a;color:#fff;font-size:18px;padding:19px}
    .sms{background:#fff7e6;color:#92400e;border:2px solid #fcd34d}
    .info{margin-top:22px;text-align:left;display:grid;gap:10px}
    .chip{background:#fff7e6;border-radius:16px;padding:14px 16px;font-family:'Manrope',sans-serif}
    .chip small{display:block;font-size:13px;font-weight:700;color:#b45309;margin-bottom:3px}
    .chip span{font-size:15px;line-height:1.45;color:#3b2a14}
    .hint{margin:10px 6px 0;font-family:'Manrope',sans-serif;font-size:13px;color:#8a6a3d;line-height:1.4}
  `;
  const loc = locationBlock('sms', alerts, d.petPhone);
  const body = `
  <main class="card">
    <div class="badge">${ic('alert', 18)} Jeśli mnie znalazłeś, pomóż mi wrócić do domu</div>
    <div class="avatar">${PAW(64)}</div>
    <h1>Cześć, jestem ${esc(name)}!</h1>
    <p class="lead">Mój opiekun na pewno się martwi. Zadzwoń do niego, a zaraz po mnie przyjdzie.</p>
    <div class="stack">
      ${d.petPhone ? `<a class="btn call" href="tel:${telNum(d.petPhone)}">${ic('phone', 22)}Zadzwoń do opiekuna</a>` : ''}
      ${loc}
    </div>
    ${loc ? '<p class="hint">Kliknij przycisk, aby wysłać właścicielowi swoją dokładną pozycję (telefon poprosi o zgodę na GPS).</p>' : ''}
    <div class="info">
      ${d.petCity ? `<div class="chip"><small>Mieszkam w okolicy</small><span>${esc(d.petCity)}</span></div>` : ''}
      ${d.petNotes ? `<div class="chip"><small>Warto wiedzieć</small><span>${esc(d.petNotes)}</span></div>` : ''}
    </div>
    <div class="legal-foot"><a href="/privacy">Prywatność i bezpieczeństwo danych</a></div>
  </main>`;
  return shell({
    title: 'Znalazłeś ' + name + '?', theme: '#fff4dc',
    font: 'Fredoka:wght@500;600&family=Manrope:wght@500;700', css, body,
    script: loc ? locationScript({ phone: d.petPhone, text: 'Cześć! Znalazłem ' + name + '.', tagId, alerts, preview: isPreview }) : ''
  });
}

function renderLost(d, tagId, isPreview, alerts) {
  const item = d.lostItem || 'Zgubiony przedmiot';
  const css = `
    body{background:#17120a;color:#fff;align-items:center;padding:20px 16px;background-image:radial-gradient(circle at 50% -10%,#5a3d0c 0,#17120a 60%)}
    .card{width:100%;max-width:400px;text-align:center}
    .keyring{width:96px;height:96px;margin:0 auto 22px;border-radius:50%;display:grid;place-items:center;background:#fbbf24;color:#3b2800;box-shadow:0 0 0 10px rgba(251,191,36,.15),0 0 0 22px rgba(251,191,36,.07)}
    h1{font-size:30px;line-height:1.15;margin:0 0 10px;font-weight:800;letter-spacing:-.01em}
    .thing{display:inline-block;font-size:16px;font-weight:700;color:#fbbf24;background:rgba(251,191,36,.12);padding:8px 16px;border-radius:999px;margin-bottom:14px}
    p.lead{margin:0 0 26px;color:#d8cfbd;font-size:16px;line-height:1.55}
    .call{background:#fbbf24;color:#2a1c00;font-size:18px;padding:19px}
    .sms{background:rgba(255,255,255,.08);color:#fff;border:1.5px solid rgba(255,255,255,.2)}
    .hint{margin:10px 6px 0;font-size:13px;color:#b8ac95;line-height:1.4}
    .reward{margin-top:20px;padding:16px;border-radius:16px;background:rgba(34,197,94,.12);border:1.5px solid rgba(34,197,94,.4);color:#86efac;font-weight:700;font-size:16px}
    .reward small{display:block;color:#bbf7d0;font-weight:600;font-size:13px;margin-bottom:3px}
  `;
  const loc = locationBlock('sms', alerts, d.lostPhone);
  const body = `
  <main class="card">
    <div class="keyring">${ic('key', 44)}</div>
    <h1>Znalazłeś moją rzecz?</h1>
    <div class="thing">${esc(item)}</div>
    <p class="lead">Dziękuję, że się zatrzymałeś. Daj mi znać, a umówimy się na odbiór.</p>
    <div class="stack">
      ${d.lostPhone ? `<a class="btn call" href="tel:${telNum(d.lostPhone)}">${ic('phone', 22)}Zadzwoń do właściciela</a>` : ''}
      ${loc}
    </div>
    ${loc ? '<p class="hint">Kliknij przycisk, aby wysłać właścicielowi swoją dokładną pozycję (telefon poprosi o zgodę na GPS).</p>' : ''}
    ${d.reward ? `<div class="reward"><small>Nagroda dla znalazcy</small>${esc(d.reward)}</div>` : ''}
    <div class="legal-foot"><a href="/privacy">Prywatność i bezpieczeństwo danych</a></div>
  </main>`;
  return shell({
    title: 'Znaleziono: ' + item, theme: '#17120a',
    font: 'Manrope:wght@500;600;700;800', css, body,
    script: loc ? locationScript({ phone: d.lostPhone, text: 'Cześć! Znalazłem: ' + item + '.', tagId, alerts, preview: isPreview }) : ''
  });
}

function renderIce(d, tagId, isPreview, alerts) {
  const css = `
    body{background:#fff;color:#1a1a1a}
    .card{width:100%;max-width:440px;min-height:100vh;min-height:100dvh;display:flex;flex-direction:column}
    .top{background:#c81e1e;color:#fff;padding:26px 24px;display:flex;gap:16px;align-items:center}
    .cross{width:54px;height:54px;border-radius:12px;background:#fff;color:#c81e1e;display:grid;place-items:center;flex:none}
    .cross .ic{stroke-width:4}
    .top h1{margin:0;font-size:20px;font-weight:800;line-height:1.2}
    .top p{margin:3px 0 0;font-size:14px;opacity:.92;font-weight:500}
    .body{padding:22px 22px 30px;display:grid;gap:14px}
    .who{font-size:30px;font-weight:800;line-height:1.1;margin:4px 0 0;letter-spacing:-.01em}
    .blood{display:flex;align-items:center;justify-content:space-between;border:3px solid #c81e1e;border-radius:16px;padding:14px 18px}
    .blood span{font-size:16px;font-weight:700;color:#7f1d1d}
    .blood b{font-size:40px;font-weight:800;color:#c81e1e;line-height:1}
    .med{background:#fff1f1;border-left:6px solid #c81e1e;border-radius:6px 14px 14px 6px;padding:14px 16px}
    .med small{display:block;font-size:14px;font-weight:800;color:#991b1b;margin-bottom:5px}
    .med p{margin:0;font-size:18px;line-height:1.5;font-weight:600;white-space:pre-line}
    .call{background:#c81e1e;color:#fff;font-size:18px;padding:20px}
    .emg{background:#1a1a1a;color:#fff}
    .sms{background:#fff1f1;color:#991b1b;border:2px solid #c81e1e}
    .hint{margin:2px 4px 0;font-size:13px;color:#7f1d1d;line-height:1.4;text-align:center}
  `;
  const loc = locationBlock('sms', alerts, d.icePhone);
  const body = `
  <main class="card">
    <header class="top">
      <div class="cross">${ic('cross', 34)}</div>
      <div><h1>Karta ratunkowa</h1><p>Dane dla ratowników i osób udzielających pomocy</p></div>
    </header>
    <section class="body">
      <h2 class="who">${esc(d.iceName || 'Dane ratunkowe')}</h2>
      ${d.blood ? `<div class="blood"><span>Grupa krwi</span><b>${esc(d.blood)}</b></div>` : ''}
      ${d.allergies ? `<div class="med"><small>Alergie, choroby, leki</small><p>${esc(d.allergies)}</p></div>` : ''}
      <div class="stack" style="margin-top:6px">
        ${d.icePhone ? `<a class="btn call" href="tel:${telNum(d.icePhone)}">${ic('phone', 22)}Zadzwoń do bliskiej osoby</a>` : ''}
        ${loc}
        <a class="btn emg" href="tel:112">${ic('phone')}Zadzwoń na 112</a>
      </div>
      ${loc ? '<p class="hint">Kliknij przycisk, aby wysłać bliskiej osobie dokładną pozycję (telefon poprosi o zgodę na GPS).</p>' : ''}
      <div class="legal-foot"><a href="/privacy">Polityka prywatności i dane medyczne</a></div>
    </section>
  </main>`;
  return shell({
    title: 'Karta ratunkowa', theme: '#c81e1e', font: 'Manrope:wght@500;600;700;800', css, body,
    script: loc ? locationScript({ phone: d.icePhone, text: 'Pilne! Otworzyłem Twoją kartę ratunkową ICE.', tagId, alerts, preview: isPreview }) : ''
  });
}

// ---------- Style wizytówki i profilu z linkami ----------
const STYLE_KEYS = ['biznes', 'barber', 'warsztat', 'uroda', 'sport', 'kawiarnia'];
const STYLE_LABELS = {
  biznes: 'Biznes (granat i złoto)',
  barber: 'Fryzjer / barber',
  warsztat: 'Serwis auto / mechanik',
  uroda: 'Salon urody',
  sport: 'Sport / trener',
  kawiarnia: 'Gastronomia / kawiarnia'
};

const STYLE_HINTS = [
  { key: 'barber',
    stems: ['fryzjer', 'fryzur', 'barber', 'golibrod', 'strzyż', 'strzyz', 'hairdress', 'zarost'],
    exact: ['hair'] },
  { key: 'warsztat',
    stems: ['mechanik', 'warsztat', 'samochod', 'pojazd', 'autoserwis', 'autonaprawa', 'autokomis', 'autolakier', 'autodetailing', 'autogielda', 'moto', 'wulkaniz', 'blacharz', 'lakiernik', 'lakiernia', 'detailing', 'opon', 'diagnostyk', 'tuning', 'hamulc', 'silnik', 'garage', 'mechanic'],
    exact: ['auto', 'auta', 'aut', 'autem', 'car', 'cars'] },
  { key: 'uroda',
    stems: ['kosmetycz', 'kosmetolog', 'paznok', 'manicure', 'pedicure', 'makijaż', 'makijaz', 'wizaż', 'wizaz', 'stylizacj', 'brwi', 'rzęs', 'rzes', 'urod', 'beauty', 'lash', 'depilac', 'masaż', 'masaz'],
    exact: ['spa', 'nails'] },
  { key: 'sport',
    stems: ['trener', 'fitness', 'siłown', 'silown', 'crossfit', 'boks', 'joga', 'yoga', 'dietety', 'gym', 'fizjoterap', 'sport', 'pilates', 'trening'],
    exact: ['fit', 'gym'] },
  { key: 'kawiarnia',
    stems: ['kawiarn', 'restaur', 'pizz', 'cukiern', 'piekar', 'bistro', 'cafe', 'coffee', 'kuchni', 'catering', 'gastro', 'burger', 'lodziar'],
    exact: ['bar', 'pub', 'kawa'] }
];

function detectStyle(...parts) {
  const words = parts.filter(Boolean).join(' ').toLowerCase().split(/[^a-z0-9ąćęłńóśźż]+/).filter(Boolean);
  for (const { key, stems, exact } of STYLE_HINTS) {
    if (words.some((w) => exact.includes(w) || stems.some((st) => w.startsWith(st)))) return key;
  }
  return '';
}

function resolveBizStyle(d) {
  if (STYLE_KEYS.includes(d.theme)) return d.theme;
  return detectStyle(d.title, d.company, d.bio, d.web, d.name) || 'biznes';
}

function resolveHubStyle(d) {
  return detectStyle(d.hubName, d.hubBio, d.hubWeb, d.instagram, d.facebook, d.tiktok, d.youtube) || 'aurora';
}

const SERIF = "'Fraunces',Georgia,'Times New Roman',serif";
const SANS = "'Manrope',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif";

const BIZ_THEMES = {
  biznes: {
    meta: '#0b1b33', body: '#0b1b33', page: '#f4f6f9', ink: '#0e1a2b', text: '#334155', mute: '#64748b',
    cover: 'linear-gradient(160deg,#0b1b33,#14284a)', coverInk: '#fff', role: '#b9c4d6', accent: '#c19a4b', accentInk: '#101010', icon: '#b8893b',
    row: '#fff', line: '#e8ecf2', monoInk: '#ecd29a', monoBorder: '#c19a4b', monoBg: 'transparent', monoRadius: '50%',
    font: SERIF, h1: `600 32px/1.1 ${SERIF}`, h1x: '',
    mark: 'briefcase', wm: 'briefcase', wmColor: '#ecd29a', wmOp: 0.1,
    deco: `.cover:before{content:"";position:absolute;inset:0;background:radial-gradient(circle at 92% 0,rgba(90,130,210,.3),transparent 55%),repeating-linear-gradient(135deg,rgba(255,255,255,.03) 0 1px,transparent 1px 14px)}
    .cover:after{content:"";position:absolute;left:0;right:0;top:0;height:3px;background:linear-gradient(90deg,#c19a4b,#ecd29a 50%,#c19a4b)}`
  },
  barber: {
    meta: '#0d0d0d', body: '#0d0d0d', page: '#f7f4ef', ink: '#141210', text: '#4a443b', mute: '#85796a',
    cover: '#0d0d0d', coverInk: '#fff', role: '#c9c0b2', accent: '#c9a96e', accentInk: '#14110c', icon: '#a8884d',
    row: '#fff', line: '#ece6dc', monoInk: '#c9a96e', monoBorder: '#c9a96e', monoBg: 'transparent', monoRadius: '50%',
    font: SERIF, h1: `600 30px/1.15 ${SERIF}`, h1x: 'text-transform:uppercase;letter-spacing:.12em;',
    mark: 'scissors', wm: 'scissors', wmColor: '#c9a96e', wmOp: 0.12,
    deco: `.cover:before{content:"";position:absolute;inset:0;background:radial-gradient(circle at 85% 100%,rgba(201,169,110,.18),transparent 55%)}
    .cover:after{content:"";position:absolute;left:28px;bottom:28px;width:44px;height:2px;background:#c9a96e}`
  },
  warsztat: {
    meta: '#101214', body: '#0b0c0e', page: '#f1f2f4', ink: '#121418', text: '#3b414a', mute: '#6a727d',
    cover: '#101214', coverInk: '#fff', role: '#aeb6c0', accent: '#e5232b', accentInk: '#fff', icon: '#d11d25',
    row: '#fff', line: '#e1e4e8', monoInk: '#fff', monoBorder: '#e5232b', monoBg: '#e5232b', monoRadius: '16px',
    font: SANS, h1: `italic 800 30px/1.08 ${SANS}`, h1x: 'text-transform:uppercase;letter-spacing:.01em;',
    mark: 'wrench', wm: 'car', wmColor: '#ffffff', wmOp: 0.07,
    deco: `.cover:before{content:"";position:absolute;inset:0;background-image:linear-gradient(135deg,rgba(255,255,255,.045) 25%,transparent 25%),linear-gradient(225deg,rgba(255,255,255,.045) 25%,transparent 25%);background-size:10px 10px}
    .cover:after{content:"";position:absolute;left:-10%;right:-10%;bottom:30px;height:3px;background:linear-gradient(90deg,transparent,#e5232b 30%,#e5232b 70%,transparent);transform:rotate(-3deg)}`
  },
  uroda: {
    meta: '#f6d9d6', body: '#f3e3e1', page: '#fbf5f3', ink: '#3a2230', text: '#5a4250', mute: '#8c6f7c',
    cover: 'linear-gradient(160deg,#f8e0dc,#efc6c9)', coverInk: '#3a2230', role: '#7a5566', accent: '#b4536a', accentInk: '#fff', icon: '#b4536a',
    row: '#fff', line: '#f1e1de', monoInk: '#b4536a', monoBorder: 'rgba(180,83,106,.5)', monoBg: 'rgba(255,255,255,.7)', monoRadius: '50%',
    font: SERIF, h1: `italic 600 33px/1.1 ${SERIF}`, h1x: '',
    mark: 'sparkles', wm: 'sparkles', wmColor: '#b4536a', wmOp: 0.16,
    deco: `.cover:before{content:"";position:absolute;inset:0;background:radial-gradient(circle at 10% 15%,rgba(255,255,255,.7),transparent 38%),radial-gradient(circle at 95% 95%,rgba(180,83,106,.22),transparent 48%),radial-gradient(rgba(255,255,255,.55) 1.2px,transparent 1.6px) 0 0/18px 18px}
    .cover:after{content:"";position:absolute;left:0;right:0;top:0;height:3px;background:linear-gradient(90deg,transparent,#b4536a,transparent)}`
  },
  sport: {
    meta: '#0b0d0b', body: '#0b0d0b', page: '#f3f4f1', ink: '#0d100c', text: '#323a2f', mute: '#667060',
    cover: '#0b0d0b', coverInk: '#fff', role: '#aab5a3', accent: '#c6f432', accentInk: '#0b0d0b', icon: '#5f8f00',
    row: '#fff', line: '#e4e8df', monoInk: '#0b0d0b', monoBorder: '#c6f432', monoBg: '#c6f432', monoRadius: '50%',
    font: SANS, h1: `800 32px/1.05 ${SANS}`, h1x: 'text-transform:uppercase;letter-spacing:-.01em;',
    mark: 'dumbbell', wm: 'dumbbell', wmColor: '#c6f432', wmOp: 0.1,
    deco: `.cover:before{content:"";position:absolute;inset:0;background:radial-gradient(circle at 100% 100%,rgba(198,244,50,.2),transparent 50%),repeating-linear-gradient(115deg,rgba(198,244,50,.06) 0 2px,transparent 2px 26px)}
    .cover:after{content:"";position:absolute;left:-10%;right:-10%;bottom:30px;height:4px;background:linear-gradient(90deg,transparent,#c6f432 25%,#c6f432 75%,transparent);transform:rotate(-3deg)}`
  },
  kawiarnia: {
    meta: '#1f2d27', body: '#16201b', page: '#f8f3ea', ink: '#25302a', text: '#4f5a50', mute: '#847f6e',
    cover: '#1f2d27', coverInk: '#fbf6ea', role: '#bfc8b6', accent: '#e0a23b', accentInk: '#1f2d27', icon: '#b9822a',
    row: '#fffdf8', line: '#e0d5bb', lineStyle: 'dashed', monoInk: '#e0a23b', monoBorder: '#e0a23b', monoBg: 'transparent', monoRadius: '50%',
    font: SERIF, h1: `600 32px/1.1 ${SERIF}`, h1x: '',
    mark: 'coffee', wm: 'coffee', wmColor: '#fbf6ea', wmOp: 0.07,
    deco: `.cover:before{content:"";position:absolute;inset:0;background:radial-gradient(circle at 20% 30%,rgba(255,255,255,.07),transparent 45%),radial-gradient(circle at 80% 80%,rgba(255,255,255,.05),transparent 40%)}
    .cover:after{content:"";position:absolute;left:28px;bottom:28px;width:44px;height:2px;background:#e0a23b}`
  }
};

function bizCss(t) {
  return `
    body{background:${t.body}}
    .card{width:100%;max-width:440px;min-height:100vh;min-height:100dvh;background:${t.page};display:flex;flex-direction:column;color:${t.ink}}
    .cover{position:relative;background:${t.cover};color:${t.coverInk};padding:56px 28px 64px;overflow:hidden}
    ${t.deco}
    .wm{position:absolute;right:-28px;bottom:-30px;width:210px;height:210px;color:${t.wmColor || '#fff'};opacity:${t.wmOp || 0};transform:rotate(-14deg);pointer-events:none}
    .wm .ic{width:100%;height:100%;stroke-width:1.1}
    .mono .ic{width:34px;height:34px;stroke-width:1.5}
    .mono{position:relative;width:76px;height:76px;border-radius:${t.monoRadius};border:1.5px solid ${t.monoBorder};background:${t.monoBg};display:grid;place-items:center;font:600 26px ${t.font};color:${t.monoInk};margin-bottom:22px}
    h1{position:relative;font:${t.h1};margin:0 0 8px;${t.h1x}}
    .role{position:relative;margin:0;color:${t.role};font-size:15px;font-weight:500}
    .main{padding:22px 22px 32px;margin-top:-30px;position:relative}
    .save{background:${t.accent};color:${t.accentInk};box-shadow:0 10px 24px -10px ${t.accent}cc}
    .bio{margin:22px 4px 6px;font-size:15px;line-height:1.6;color:${t.text}}
    .rows{margin-top:18px;background:${t.row};border-radius:16px;overflow:hidden}
    .row{display:flex;align-items:center;gap:14px;padding:16px 18px;text-decoration:none;color:${t.ink};border-bottom:1px ${t.lineStyle || 'solid'} ${t.line}}
    .row:last-child{border-bottom:0}
    .row .ic{color:${t.icon}}
    .row small{display:block;color:${t.mute};font-size:13px;font-weight:600;margin-bottom:2px}
    .row b{font-size:15px;font-weight:600;word-break:break-word}
  `;
}

const HUB_THEMES = {
  aurora: {
    base: '#0a0f1f', blobs: ['#6d5dfc88', '#18c6ff55', '#ff4fd844'], tx: '#fff', tx2: '#c7cbe8',
    glass: 'rgba(255,255,255,.08)', glassb: 'rgba(255,255,255,.16)', grid: 'rgba(255,255,255,.045)',
    logoBg: 'linear-gradient(135deg,#6d5dfc,#18c6ff)', logoInk: '#fff'
  },
  biznes: {
    base: '#0b1626', blobs: ['#1f4b8f88', '#b8893b44', '#16314f99'], tx: '#fff', tx2: '#bcc7d8',
    glass: 'rgba(255,255,255,.08)', glassb: 'rgba(255,255,255,.15)', grid: 'rgba(255,255,255,.04)',
    logoBg: 'linear-gradient(135deg,#e1c07a,#b8893b)', logoInk: '#101010'
  },
  barber: {
    base: '#0d0d0d', blobs: ['#c9a96e55', '#7a5a2a66', '#2a2418cc'], tx: '#fff', tx2: '#cfc6b8',
    glass: 'rgba(255,255,255,.06)', glassb: 'rgba(201,169,110,.28)', grid: 'rgba(201,169,110,.05)',
    logoBg: 'linear-gradient(135deg,#e6cf9d,#c9a96e)', logoInk: '#14110c'
  },
  warsztat: {
    base: '#0b0c0e', blobs: ['#e5232b55', '#5a0f13aa', '#1b1d22cc'], tx: '#fff', tx2: '#b4bcc6',
    glass: 'rgba(255,255,255,.06)', glassb: 'rgba(229,35,43,.32)', grid: 'rgba(255,255,255,.04)',
    logoBg: 'linear-gradient(135deg,#ff4a52,#e5232b)', logoInk: '#fff'
  },
  uroda: {
    base: '#fbf1ef', blobs: ['#f6c6cc99', '#ecc3e088', '#ffd9c299'], tx: '#3a2230', tx2: '#7a5566',
    glass: 'rgba(255,255,255,.72)', glassb: 'rgba(180,83,106,.16)', grid: 'rgba(180,83,106,.06)',
    logoBg: 'linear-gradient(135deg,#d96d86,#b4536a)', logoInk: '#fff'
  },
  sport: {
    base: '#080a08', blobs: ['#c6f43255', '#2d4a0099', '#0f1a05cc'], tx: '#fff', tx2: '#b5bfae',
    glass: 'rgba(255,255,255,.07)', glassb: 'rgba(198,244,50,.25)', grid: 'rgba(198,244,50,.05)',
    logoBg: 'linear-gradient(135deg,#dcff63,#c6f432)', logoInk: '#0b0d0b'
  },
  kawiarnia: {
    base: '#16201b', blobs: ['#e0a23b44', '#2f5a45aa', '#0f1712cc'], tx: '#fbf6ea', tx2: '#bfc8b6',
    glass: 'rgba(255,255,255,.07)', glassb: 'rgba(224,162,59,.28)', grid: 'rgba(251,246,234,.04)',
    logoBg: 'linear-gradient(135deg,#f0bd62,#e0a23b)', logoInk: '#1f2d27'
  }
};

function hubCss(p) {
  return `
    body{background:${p.base};color:${p.tx};padding:44px 18px 40px;align-items:flex-start}
    .bg{position:fixed;inset:0;z-index:0;pointer-events:none;background:
      radial-gradient(60% 45% at 12% 4%,${p.blobs[0]} 0,transparent 70%),
      radial-gradient(55% 42% at 100% 34%,${p.blobs[1]} 0,transparent 70%),
      radial-gradient(65% 48% at 0 100%,${p.blobs[2]} 0,transparent 70%)}
    .bg:after{content:"";position:absolute;inset:0;background-image:linear-gradient(${p.grid} 1px,transparent 1px),linear-gradient(90deg,${p.grid} 1px,transparent 1px);background-size:44px 44px;-webkit-mask-image:radial-gradient(ellipse at 50% 0,#000 0,transparent 72%);mask-image:radial-gradient(ellipse at 50% 0,#000 0,transparent 72%)}
    .card{position:relative;z-index:1;width:100%;max-width:420px;text-align:center}
    .logo{width:92px;height:92px;margin:0 auto 18px;border-radius:50%;background:${p.logoBg};color:${p.logoInk};display:grid;place-items:center;font-size:32px;font-weight:800;box-shadow:0 0 0 5px ${p.glass},0 18px 40px -14px rgba(0,0,0,.55)}
    h1{margin:0 0 8px;font-size:30px;line-height:1.1;font-weight:800;letter-spacing:-.02em}
    .bio{margin:0 auto 28px;max-width:320px;font-size:15px;line-height:1.5;color:${p.tx2}}
    .link{display:flex;align-items:center;gap:14px;padding:10px 16px 10px 10px;border-radius:18px;background:${p.glass};border:1px solid ${p.glassb};-webkit-backdrop-filter:blur(14px);backdrop-filter:blur(14px);color:${p.tx};text-decoration:none;font-weight:700;font-size:16px;text-align:left;transition:transform .12s ease;animation:hubIn .5s ease both}
    .link:after{content:"\\203A";margin-left:auto;font-size:24px;line-height:1;opacity:.45}
    .link:active{transform:scale(.98)}
    .dot{width:44px;height:44px;border-radius:14px;display:grid;place-items:center;color:#fff;flex:none;box-shadow:0 6px 14px -6px rgba(0,0,0,.5)}
    @keyframes hubIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}
    @media (prefers-reduced-motion:reduce){.link{animation:none}}
  `;
}

function renderBiz(d, tagId, currentUrl) {
  const role = [d.title, d.company].filter(Boolean).map(esc).join(' w ');
  const t = BIZ_THEMES[resolveBizStyle(d)];
  const css = bizCss(t);
  const body = `
  <main class="card">
    <header class="cover">
      ${t.wm ? `<div class="wm" aria-hidden="true">${ic(t.wm, 210)}</div>` : ''}
      <div class="mono">${ic(t.mark, 34)}</div>
      <h1>${esc(d.name || 'Twoje imię')}</h1>
      ${role ? `<p class="role">${role}</p>` : ''}
    </header>
    <section class="main">
      <a class="btn save" href="/tag/${encodeURIComponent(tagId)}?vcard=1">${ic('addUser')}Zapisz w kontaktach</a>
      ${d.bio ? `<p class="bio">${esc(d.bio)}</p>` : ''}
      <div class="rows">
        ${d.phone ? `<a class="row" href="tel:${telNum(d.phone)}">${ic('phone')}<span><small>Telefon</small><b>${esc(d.phone)}</b></span></a>` : ''}
        ${d.email ? `<a class="row" href="mailto:${esc(d.email)}">${ic('mail')}<span><small>E-mail</small><b>${esc(d.email)}</b></span></a>` : ''}
        ${d.web ? `<a class="row" href="${esc(fullUrl(d.web))}" target="_blank" rel="noopener">${ic('globe')}<span><small>Strona</small><b>${esc(d.web.replace(/^https?:\/\//i, '').replace(/\/$/, ''))}</b></span></a>` : ''}
      </div>
      ${qrShare}
      <div class="legal-foot"><a href="/privacy">Polityka prywatności</a></div>
    </section>
  </main>`;
  return shell({ title: d.name || 'Wizytówka', theme: t.meta, font: 'Fraunces:wght@600&family=Manrope:wght@500;600;700', css, body, script: qrScript(currentUrl) });
}

function hubLinks(d) {
  const wa = d.whatsapp ? 'https://wa.me/' + telNum(d.whatsapp).replace(/^\+/, '') : '';
  return [
    { label: 'Zostaw opinię w Google', icon: 'star', href: d.google ? fullUrl(d.google) : '', color: '#f59e0b' },
    { label: 'Instagram', icon: 'instagram', href: handleUrl(d.instagram, 'https://instagram.com/'), color: '#e1306c' },
    { label: 'TikTok', icon: 'tiktok', href: handleUrl(d.tiktok, 'https://tiktok.com/@'), color: '#111111' },
    { label: 'Facebook', icon: 'facebook', href: handleUrl(d.facebook, 'https://facebook.com/'), color: '#1877f2' },
    { label: 'YouTube', icon: 'youtube', href: handleUrl(d.youtube, 'https://youtube.com/@'), color: '#e11d1d' },
    { label: 'Napisz na WhatsApp', icon: 'sms', href: wa, color: '#16a34a' },
    { label: 'Strona internetowa', icon: 'globe', href: d.hubWeb ? fullUrl(d.hubWeb) : '', color: '#334155' }
  ].filter((l) => l.href);
}

function renderHub(d, links, currentUrl) {
  const name = d.hubName || 'Moje linki';
  const initials = name.trim().split(/\s+/).map((n) => n[0]).slice(0, 2).join('').toUpperCase();
  const p = HUB_THEMES[resolveHubStyle(d)];
  const css = hubCss(p);
  const body = `
  <div class="bg" aria-hidden="true"></div>
  <main class="card">
    <div class="logo">${esc(initials)}</div>
    <h1>${esc(name)}</h1>
    ${d.hubBio ? `<p class="bio">${esc(d.hubBio)}</p>` : '<div style="height:24px"></div>'}
    <div class="stack">
      ${links.map((l, i) => `<a class="link" style="animation-delay:${i * 60}ms" href="${esc(l.href)}" target="_blank" rel="noopener"><span class="dot" style="background:${l.color}">${ic(l.icon, 22)}</span>${esc(l.label)}</a>`).join('')}
    </div>
    ${qrShare}
    <div class="legal-foot"><a href="/privacy">Polityka prywatności</a></div>
  </main>`;
  return shell({ title: name, theme: p.base, font: 'Manrope:wght@500;700;800', css, body, script: qrScript(currentUrl) });
}

function renderPay(d) {
  const amount = d.pAmount ? (/^[\d\s.,]+$/.test(d.pAmount) ? d.pAmount.trim() + ' zł' : d.pAmount) : '';
  const revolut = handleUrl(d.pRevolut, 'https://revolut.me/');
  const paypal = handleUrl(d.pPaypal, 'https://paypal.me/');
  const iban = String(d.pIban || '').replace(/\s+/g, '').toUpperCase();
  const ibanPretty = /^\d{26}$/.test(iban)
    ? iban.replace(/^(\d{2})(.*)$/, (m, a, b) => a + ' ' + b.replace(/(.{4})/g, '$1 ').trim())
    : iban.replace(/(.{4})/g, '$1 ').trim();
  const blik = d.pBlik ? String(d.pBlik).trim() : '';
  const row = (label, val, shown) =>
    `<div class="crow"><div><small>${label}</small><b>${esc(shown || val)}</b></div>
     <button class="cp" data-v="${esc(val)}" aria-label="Kopiuj: ${esc(label)}">${ic('copy', 20)}</button></div>`;
  const css = `
    body{background:#0c3b2e;background-image:radial-gradient(circle at 50% -20%,#1f7a5c 0,transparent 60%);align-items:center;padding:20px 16px;color:#0c2a20}
    .card{width:100%;max-width:400px;background:#fff;border-radius:28px;padding:30px 22px 22px;box-shadow:0 24px 50px -20px rgba(0,0,0,.6)}
    .who{margin:0;font-size:15px;color:#4b6b5f;font-weight:600}
    h1{margin:4px 0 0;font-size:32px;line-height:1.1;font-weight:800;letter-spacing:-.02em}
    .amount{margin:18px 0 0;font-size:46px;line-height:1;font-weight:800;letter-spacing:-.03em;color:#0c3b2e}
    .methods{margin-top:24px;display:grid;gap:10px}
    .rev{background:#191c1f;color:#fff}
    .pp{background:#0070e0;color:#fff}
    .crow{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:14px 14px 14px 18px;border-radius:14px;background:#eef6f2}
    .crow small{display:block;font-size:13px;color:#4b6b5f;font-weight:600;margin-bottom:3px}
    .crow b{font-size:16px;font-weight:700;word-break:break-all;font-variant-numeric:tabular-nums}
    .cp{flex:none;width:46px;height:46px;border-radius:12px;border:0;background:#0c3b2e;color:#fff;display:grid;place-items:center;cursor:pointer;transition:background .15s}
    .cp.done{background:#16a34a}
    .note{margin:14px 4px 0;font-size:13px;color:#5f7d71;line-height:1.5;text-align:center}
  `;
  const body = `
  <main class="card">
    ${d.pName ? `<p class="who">Dla: ${esc(d.pName)}</p>` : ''}
    <h1>${esc(d.pPurpose || 'Płatność')}</h1>
    ${amount ? `<p class="amount">${esc(amount)}</p>` : ''}
    <div class="methods">
      ${revolut ? `<a class="btn rev" href="${esc(revolut)}" target="_blank" rel="noopener">${ic('card')}Zapłać przez Revolut</a>` : ''}
      ${paypal ? `<a class="btn pp" href="${esc(paypal)}" target="_blank" rel="noopener">${ic('card')}Zapłać przez PayPal</a>` : ''}
      ${blik ? row('BLIK na telefon', blik) : ''}
      ${iban ? row('Przelew na konto', iban, ibanPretty) : ''}
    </div>
    ${blik ? '<p class="note">BLIK na telefon: w aplikacji banku wybierz "Przelew na telefon" i wklej numer.</p>' : ''}
    <div class="legal-foot"><a href="/privacy">Prywatność i bezpieczeństwo transakcji</a></div>
  </main>`;
  const script = `
    document.querySelectorAll('.cp').forEach(function(b){
      b.onclick=function(){
        var v=b.dataset.v;
        (navigator.clipboard?navigator.clipboard.writeText(v):Promise.reject()).catch(function(){
          var t=document.createElement('textarea'); t.value=v; document.body.appendChild(t); t.select(); document.execCommand('copy'); t.remove();
        }).then(function(){ b.classList.add('done'); setTimeout(function(){ b.classList.remove('done'); },1800); });
      };
    });`;
  return shell({ title: d.pPurpose || 'Płatność', theme: '#0c3b2e', font: 'Manrope:wght@500;600;700;800', css, body, script });
}

function renderWifi(d) {
  const sec = d.security === 'nopass' ? 'nopass' : 'WPA';
  const esq = (s) => String(s || '').replace(/([\\;,:"])/g, '\\$1');
  const wifiString = `WIFI:T:${sec};S:${esq(d.ssid)};${sec === 'nopass' ? '' : 'P:' + esq(d.password) + ';'};`;
  const css = `
    body{background:#06122b;color:#fff;align-items:center;padding:20px 16px;background-image:radial-gradient(circle at 50% 0,#0b3d91 0,#06122b 62%)}
    .card{width:100%;max-width:400px;text-align:center}
    .radar{position:relative;width:132px;height:132px;margin:0 auto 22px;display:grid;place-items:center;color:#7dd3fc}
    .radar i{position:absolute;inset:0;border-radius:50%;border:1.5px solid rgba(125,211,252,.55);animation:ping 3s ease-out infinite}
    .radar i:nth-child(2){animation-delay:1s}.radar i:nth-child(3){animation-delay:2s}
    @keyframes ping{from{transform:scale(.45);opacity:1}to{transform:scale(1.15);opacity:0}}
    .radar .ic{stroke-width:2.2}
    h1{font-size:28px;margin:0 0 4px;font-weight:800;letter-spacing:-.01em}
    .sub{margin:0 0 24px;color:#a9bfdf;font-size:15px}
    .box{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.14);border-radius:18px;padding:16px 18px;text-align:left;margin-bottom:10px}
    .box small{display:block;color:#9bbbe6;font-size:13px;font-weight:600;margin-bottom:4px}
    .val{font:600 20px 'JetBrains Mono',ui-monospace,monospace;word-break:break-all}
    .pass{display:flex;align-items:center;justify-content:space-between;gap:12px}
    .eye{background:none;border:0;color:#9bbbe6;padding:6px;cursor:pointer}
    .copy{margin-top:8px;background:#38bdf8;color:#04223a}
    .qr{margin-top:22px;padding:18px;background:#fff;border-radius:20px;display:grid;justify-items:center;gap:10px;color:#0b1b36}
    .qr small{font-size:13px;font-weight:600;color:#475569;line-height:1.4}
    #qr{width:168px;height:168px}
  `;
  const body = `
  <main class="card">
    <div class="radar"><i></i><i></i><i></i>${ic('wifi', 56)}</div>
    <h1>Połącz się z Wi-Fi</h1>
    <p class="sub">Skopiuj hasło albo zeskanuj kod aparatem</p>
    <div class="box"><small>Nazwa sieci</small><div class="val">${esc(d.ssid || '-')}</div></div>
    ${sec === 'nopass' ? '<div class="box"><small>Hasło</small><div class="val">sieć otwarta</div></div>' : `
    <div class="box"><small>Hasło</small>
      <div class="pass"><div class="val" id="pw" data-v="${esc(d.password || '')}">••••••••</div>
      <button class="eye" id="eye" aria-label="Pokaż hasło">${ic('eye', 22)}</button></div>
    </div>
    <button class="btn copy" id="copy">${ic('copy')}<span>Kopiuj hasło</span></button>`}
    <div class="qr"><div id="qr"></div><small>Zeskanuj aparatem w telefonie gościa,<br>a połączy się automatycznie</small></div>
    <div class="legal-foot"><a href="/privacy">Polityka prywatności</a></div>
  </main>`;
  const script = qrLoader + `
    var pw=document.getElementById('pw'), shown=false;
    var eye=document.getElementById('eye'), cp=document.getElementById('copy');
    if(eye) eye.onclick=function(){ shown=!shown; pw.textContent=shown?pw.dataset.v:'••••••••'; };
    if(cp) cp.onclick=function(){
      var s=cp.querySelector('span'), v=pw.dataset.v;
      (navigator.clipboard?navigator.clipboard.writeText(v):Promise.reject()).catch(function(){
        var t=document.createElement('textarea'); t.value=v; document.body.appendChild(t); t.select(); document.execCommand('copy'); t.remove();
      }).then(function(){ s.textContent='Skopiowano'; setTimeout(function(){ s.textContent='Kopiuj hasło'; },2000); });
    };
    loadQr(function(){ new QRCode(document.getElementById('qr'),{text:${jsonForScript(wifiString)},width:168,height:168,correctLevel:QRCode.CorrectLevel.M}); });`;
  return shell({ title: 'Wi-Fi: ' + (d.ssid || ''), theme: '#06122b', font: 'Manrope:wght@500;600;700;800&family=JetBrains+Mono:wght@600', css, body, script });
}

const MODE_DESC = {
  pet: 'Gdy ktoś znajdzie Twojego zwierzaka, zobaczy jego imię i przycisk „Zadzwoń do opiekuna”.',
  lost: 'Gdy ktoś znajdzie Twoją rzecz, jednym kliknięciem zadzwoni do Ciebie.',
  biz: 'Wizytówka: imię, telefon, e-mail i strona, z przyciskiem „Zapisz w kontaktach”.',
  link: 'Po przyłożeniu telefonu brelok od razu otwiera wskazaną stronę internetową.',
  hub: 'Jedna strona z przyciskami do Instagrama, TikToka, Facebooka, opinii Google, WhatsAppa i Twojej strony.',
  pay: 'Pokazuje dane do płatności (BLIK, Revolut, PayPal, numer konta) z kopiowaniem jednym kliknięciem.',
  ice: 'Ważne informacje dla ratowników: grupa krwi, alergie, leki i telefon do bliskiej osoby.',
  wifi: 'Goście łączą się z Twoim Wi-Fi jednym skanem, bez wpisywania hasła.'
};

function renderAdmin(tagId, token, d, msg = '', caps = {}, currentAdminUrl = '') {
  const allowed = Array.isArray(d.allowed) && d.allowed.length ? d.allowed.filter((m) => MODES.includes(m)) : MODES;
  let t = d.type || '';
  if (!allowed.includes(t)) t = allowed[0] || 'pet';
  const isNotifyActive = d.notifyActive !== '0';
  const allModes = [
    ['pet', 'Zwierzak', 'paw'], ['lost', 'Zgubiony przedmiot', 'key'], ['biz', 'Wizytówka', 'addUser'], ['link', 'Link do strony', 'link'],
    ['hub', 'Social media', 'instagram'], ['pay', 'Płatności i napiwki', 'card'],
    ['ice', 'Karta ratunkowa', 'cross'], ['wifi', 'Wi-Fi dla gości', 'wifi']
  ];
  const modes = allModes.filter(([v]) => allowed.includes(v));
  const field = (label, name, val, ph = '', type = 'text') =>
    `<label>${label}<input type="${type}" name="${name}" value="${esc(val)}" placeholder="${esc(ph)}" maxlength="600"></label>`;
  const area = (label, name, val, ph = '') =>
    `<label>${label}<textarea name="${name}" rows="3" maxlength="600" placeholder="${esc(ph)}">${esc(val)}</textarea></label>`;

  const css = `
    body{background:#eef1f5;color:#0f172a;align-items:flex-start;padding:20px 14px 40px}
    .wrap{width:100%;max-width:460px;background:#fff;border-radius:22px;padding:22px 20px 24px;box-shadow:0 12px 30px -16px rgba(15,23,42,.3)}
    .brand-bar{display:flex;align-items:center;justify-content:space-between;padding-bottom:14px;margin-bottom:14px;border-bottom:1px solid #eef1f5}
    .tag-pill{font-size:12px;font-weight:700;color:#64748b;font-family:'JetBrains Mono',monospace;background:#f1f5f9;padding:4px 10px;border-radius:8px}
    .head{display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:14px}
    h1{font-size:19px;margin:0;font-weight:800}
    .prev{font-size:13px;font-weight:700;color:#0f172a;text-decoration:none;padding:8px 12px;border-radius:999px;background:#eef1f5}
    .dirty{display:none;margin-bottom:14px;padding:11px 14px;border-radius:12px;background:#fff4e0;color:#8a5a00;font-size:14px;font-weight:700;line-height:1.4}
    .dirty.show{display:block}
    .more{margin-top:26px;padding-top:14px;border-top:1px dashed #d5dbe4;text-align:center}
    .more summary{display:inline-block;cursor:pointer;font-size:12px;font-weight:600;color:#94a3b3;list-style:none;padding:6px 10px}
    .more summary::-webkit-details-marker{display:none}
    .more-body{margin-top:10px;padding:14px;border-radius:14px;background:#fff5f5;border:1px solid #f3c9c9;text-align:left}
    .more-body p{margin:0 0 12px;font-size:13px;line-height:1.5;color:#7a2e2e}
    .clearbtn{width:100%;padding:12px 14px;border-radius:12px;border:1.5px solid #d64545;background:#fff;color:#c43030;font:700 14px/1.2 inherit;font-family:inherit;cursor:pointer}
    .prev.dim{opacity:.45}
    .ok{padding:14px 16px;background:#e8f8ee;color:#14532d;border-radius:14px;margin-bottom:16px;font-size:14px;line-height:1.45}
    .ok b{display:block;font-size:16px;margin-bottom:4px}
    .ok p{margin:0 0 12px;color:#166534}
    .ok .opt{background:#fff;border-color:#bfe6cd}
    .seeprofile{display:inline-block;margin-top:12px;font-weight:800;color:#14532d}
    .opt{display:flex;align-items:center;gap:10px;width:100%;padding:13px 14px;background:#fff;border:1.5px solid #dbe1ea;border-radius:12px;font:700 15px inherit;font-family:inherit;color:#0f172a;text-decoration:none;text-align:left;cursor:pointer}
    .opt .ic{color:#475569}
    .lnk-actions{display:grid;gap:8px}
    .linkbox{margin-top:22px;padding:16px;border-radius:14px;background:#f6f8fb}
    .linkbox b{display:block;font-size:15px;margin-bottom:4px}
    .linkbox p{margin:0 0 12px;font-size:13px;line-height:1.5;color:#64748b}
    .lead{margin:0 0 10px;font-size:15px;font-weight:700;color:#0f172a}
    .modedesc{margin:8px 2px 0;padding:12px 14px;background:#f1f5f9;border-radius:12px;font-size:14px;line-height:1.5;color:#334155}
    .modes{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:6px}
    .modes label{margin:0;position:relative}
    .modes input{position:absolute;opacity:0;pointer-events:none}
    .mode{display:grid;justify-items:center;align-content:center;gap:6px;min-height:76px;padding:10px 2px;border-radius:14px;border:1.5px solid #dbe1ea;background:#fff;font-size:12px;line-height:1.2;text-align:center;font-weight:700;color:#475569;cursor:pointer;transition:all .12s}
    .modes input:checked + .mode{background:#0f172a;border-color:#0f172a;color:#fff}
    .modes input:focus-visible + .mode{outline:3px solid #38bdf8;outline-offset:2px}
    .single{display:flex;align-items:center;gap:10px;padding:12px 14px;border-radius:12px;background:#f1f5f9;font-size:15px;margin-bottom:6px}
    .sec{display:none;margin-top:8px}
    label{display:block;font-size:13px;font-weight:700;color:#475569;margin-top:14px}
    input[type=text],input[type=tel],input[type=email],textarea,select{display:block;width:100%;margin-top:6px;padding:13px 14px;background:#f6f8fb;border:1.5px solid #dbe1ea;border-radius:12px;font:500 16px inherit;font-family:inherit;color:#0f172a;outline:none}
    input:focus,textarea:focus,select:focus{border-color:#0f172a;background:#fff}
    .save{background:#0f172a;color:#fff}
    .alt{background:#eef1f5;color:#0f172a}
    .actions{position:sticky;bottom:0;display:grid;gap:8px;margin:20px -20px -24px;padding:16px 20px 22px;background:linear-gradient(to top,#fff 75%,rgba(255,255,255,0));border-radius:0 0 22px 22px}
    .toast{position:fixed;left:50%;bottom:150px;transform:translate(-50%,16px);width:max-content;max-width:calc(100% - 32px);padding:13px 18px;border-radius:14px;background:#0f172a;color:#fff;font:700 14px/1.4 inherit;font-family:inherit;text-align:center;opacity:0;pointer-events:none;transition:opacity .25s,transform .25s;z-index:100}
    .toast.show{opacity:1;transform:translate(-50%,0)}
    .hint{font-size:13px;color:#64748b;margin:10px 0 0;line-height:1.5}
    .notif{margin-top:24px;padding:16px;background:#f6f8fb;border-radius:14px;font-size:15px}
    .notif a{color:#0f172a;font-weight:700}
    .notif .btn.pair{margin-top:14px;background:#229ed9;color:#fff;font-size:16px}
    .btn-manual-check{display:none;margin-top:8px;background:#334155;color:#fff;font-size:13px;padding:10px}
    .paired{margin-top:14px;padding:12px 14px;border-radius:12px;background:#e8f8ee;color:#166534;font-weight:700;font-size:15px}
    .unlink{display:flex;align-items:center;gap:10px;margin-top:10px;font-size:14px;font-weight:600;cursor:pointer}
    .unlink input{width:18px;height:18px;margin:0;accent-color:#0f172a}
    details{margin-top:14px}
    summary{font-size:14px;font-weight:700;color:#475569;cursor:pointer;padding:6px 0}
    .sw{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:0;font-size:15px;font-weight:700;color:#0f172a;cursor:pointer;position:relative}
    .sw input{position:absolute;opacity:0;width:1px;height:1px}
    .sw i{flex:none;width:50px;height:30px;border-radius:999px;background:#cbd5e1;position:relative;transition:background .15s}
    .sw i:after{content:"";position:absolute;top:3px;left:3px;width:24px;height:24px;border-radius:50%;background:#fff;transition:transform .15s;box-shadow:0 1px 3px rgba(0,0,0,.3)}
    .sw input:checked + i{background:#16a34a}
    .sw input:checked + i:after{transform:translateX(20px)}
    .sw input:focus-visible + i{outline:3px solid #38bdf8;outline-offset:2px}
    .guide{margin-top:20px;padding:14px;border-radius:12px;background:#f8fafc;border:1px dashed #cbd5e1;font-size:13px;line-height:1.5;color:#64748b}
    .guide b{color:#334155}
  `;
  const adminLink = currentAdminUrl || '';
  const mailHref = 'mailto:?subject=' + encodeURIComponent('Mój brelok ' + BRAND + ' - panel') +
    '&body=' + encodeURIComponent('Link do panelu breloka #' + tagId + ':\n' + adminLink +
    '\n\nNie udostępniaj go nikomu - daje dostęp do edycji breloka.');
  const previewHref = '/tag/' + encodeURIComponent(tagId) + '?preview=' + encodeURIComponent(token);
  const linkActions = `<div class="lnk-actions">
        <button type="button" class="opt js-copy">${ic('copy', 18)}<span>Skopiuj link</span></button>
        <a class="opt" href="${esc(mailHref)}">${ic('mail', 18)}<span>Wyślij link na swój e-mail</span></a>
      </div>`;
  const body = `
  <main class="wrap">
    <div class="brand-bar">
      ${LOGO_POZIOME_JASNE}
      <span class="tag-pill">#${esc(tagId)}</span>
    </div>
    <div class="head"><h1>Ustawienia breloka</h1>
      <a class="prev" id="prevLink" href="${esc(previewHref)}" target="_blank" rel="noreferrer">Zobacz zapisany profil</a></div>
    <div class="dirty" id="dirtyBar" role="status">Masz niezapisane zmiany. Kliknij „Zapisz zmiany” na dole strony.</div>

    ${msg ? `<div class="ok" role="status">
      <b>✓ ${esc(msg)}</b>
      <p>Zapisz teraz ten link w telefonie. Dzięki niemu zawsze wrócisz tutaj i zmienisz dane breloka.</p>
      ${linkActions}
      <a class="seeprofile" href="${esc(previewHref)}" target="_blank" rel="noreferrer">Zobacz, jak wygląda Twój brelok →</a>
    </div>` : ''}
    <form method="POST">
      ${modes.length > 1
        ? `<p class="lead">Wybierz, co ma się wyświetlić po przyłożeniu telefonu do breloka:</p>
      <div class="modes" style="grid-template-columns:repeat(${Math.min(4, modes.length)},1fr)">
        ${modes.map(([v, l, i]) => `<label><input type="radio" name="mode" value="${v}" required ${t === v ? 'checked' : ''}><span class="mode">${ic(i, 22)}${l}</span></label>`).join('')}
      </div>
      <div class="modedesc" id="modeDesc" aria-live="polite"></div>
      <p class="hint">Dane wpisane w innych zakładkach nie znikną. Zmienia się tylko to, co pokazuje brelok.</p>`
        : `<input type="hidden" name="mode" value="${modes[0][0]}">
           <div class="single">${ic(modes[0][2], 22)}<b>${modes[0][1]}</b></div>`}

      ${allowed.includes('pet') ? `
      <div class="sec" id="sec-pet">
        ${field('Imię zwierzaka', 'petName', d.petName, 'Imię Twojego zwierzaka')}
        ${field('Telefon do opiekuna', 'petPhone', d.petPhone, 'Numer telefonu (np. 123 456 789)', 'tel')}
        ${field('Miasto lub dzielnica', 'petCity', d.petCity, 'Twoje miasto lub dzielnica')}
        ${area('Warto wiedzieć', 'petNotes', d.petNotes, 'Np. przyjazny, boi się burzy, potrzebuje leków')}
      </div>` : ''}

      ${allowed.includes('lost') ? `
      <div class="sec" id="sec-lost">
        ${field('Co to za przedmiot', 'lostItem', d.lostItem, 'Np. klucze do auta')}
        ${field('Telefon do właściciela', 'lostPhone', d.lostPhone, 'Numer telefonu', 'tel')}
        ${field('Nagroda dla znalazcy', 'reward', d.reward, 'Np. 50 zł albo kawa')}
      </div>` : ''}

      ${allowed.includes('biz') ? `
      <div class="sec" id="sec-biz">
        ${field('Imię i nazwisko', 'name', d.name, 'Twoje imię i nazwisko')}
        ${field('Stanowisko', 'title', d.title, 'Twoje stanowisko')}
        ${field('Firma', 'company', d.company, 'Nazwa Twojej firmy')}
        ${field('Telefon', 'phone', d.phone, 'Twój numer telefonu', 'tel')}
        ${field('E-mail', 'email', d.email, 'Twój adres e-mail', 'email')}
        ${field('Strona WWW', 'web', d.web, 'Adres Twojej strony')}
        ${area('Krótki opis', 'bio', d.bio, 'Kilka słów o Tobie lub ofercie')}
        <label>Styl wizytówki
          <select name="theme">
            <option value="" ${!STYLE_KEYS.includes(d.theme) ? 'selected' : ''}>Dopasuj automatycznie do opisu</option>
            ${STYLE_KEYS.map((k) => `<option value="${k}" ${d.theme === k ? 'selected' : ''}>${STYLE_LABELS[k]}</option>`).join('')}
          </select>
        </label>
        <p class="hint">Automat wybiera wygląd po stanowisku, firmie, opisie i adresie strony (np. fryzjer, mechanik, kosmetyczka). Możesz też wybrać styl ręcznie.</p>
      </div>` : ''}

      ${allowed.includes('link') ? `
      <div class="sec" id="sec-link">
        ${field('Adres docelowy', 'url', d.url, 'Wklej link')}
        <p class="hint">Po zeskanowaniu brelok od razu otwiera ten adres.</p>
      </div>` : ''}

      ${allowed.includes('hub') ? `
      <div class="sec" id="sec-hub">
        ${field('Nazwa profilu', 'hubName', d.hubName, 'Twoja firma lub imię')}
        ${area('Krótki opis', 'hubBio', d.hubBio, 'Opis w jednym zdaniu')}
        ${field('Opinie Google', 'google', d.google, 'Link do opinii')}
        ${field('Instagram', 'instagram', d.instagram, 'Twój profil')}
        ${field('TikTok', 'tiktok', d.tiktok, 'Twój profil')}
        ${field('Facebook', 'facebook', d.facebook, 'Twoja strona')}
        ${field('YouTube', 'youtube', d.youtube, 'Twój kanał')}
        ${field('WhatsApp (numer)', 'whatsapp', d.whatsapp, 'Twój numer telefonu', 'tel')}
        ${field('Strona WWW', 'hubWeb', d.hubWeb, 'Adres strony')}
      </div>` : ''}

      ${allowed.includes('pay') ? `
      <div class="sec" id="sec-pay">
        ${field('Odbiorca', 'pName', d.pName, 'Twoje imię lub nazwa')}
        ${field('Tytuł', 'pPurpose', d.pPurpose, 'Np. napiwek')}
        ${field('Kwota', 'pAmount', d.pAmount, 'Np. 20')}
        ${field('BLIK na telefon', 'pBlik', d.pBlik, 'Numer telefonu', 'tel')}
        ${field('Revolut', 'pRevolut', d.pRevolut, 'Tag Revolut')}
        ${field('PayPal', 'pPaypal', d.pPaypal, 'Tag PayPal')}
        ${field('Numer konta', 'pIban', d.pIban, 'Numer konta bankowego')}
      </div>` : ''}

      ${allowed.includes('ice') ? `
      <div class="sec" id="sec-ice">
        ${field('Imię i nazwisko', 'iceName', d.iceName, 'Twoje imię i nazwisko')}
        ${field('Grupa krwi', 'blood', d.blood, 'Twoja grupa krwi')}
        ${field('Telefon ratunkowy', 'icePhone', d.icePhone, 'Numer do bliskiej osoby', 'tel')}
        ${area('Alergie i leki', 'allergies', d.allergies, 'Alergie, choroby, stałe leki')}
        <label class="unlink" style="align-items:flex-start;font-size:13px;font-weight:500;line-height:1.5"><input type="checkbox" name="healthConsent" value="1" ${d.healthConsentAt ? 'checked' : ''} style="margin-top:3px;flex:none"><span>Wyrażam wyraźną zgodę na zapisanie i <b>publiczne</b> wyświetlanie podanych tu danych o zdrowiu (grupa krwi, alergie, leki) każdemu, kto zeskanuje brelok lub pozna jego adres. Zgodę mogę wycofać, usuwając te dane. Dane wpisuję sam/a, mogą być nieaktualne i nie zastępują dokumentacji medycznej.</span></label>
      </div>` : ''}

      ${allowed.includes('wifi') ? `
      <div class="sec" id="sec-wifi">
        ${field('Nazwa sieci', 'ssid', d.ssid, 'Nazwa sieci Wi-Fi')}
        ${field('Hasło', 'password', d.password, 'Hasło do sieci')}
        <label>Zabezpieczenie
          <select name="security">
            <option value="WPA" ${d.security !== 'nopass' ? 'selected' : ''}>WPA / WPA2 / WPA3</option>
            <option value="nopass" ${d.security === 'nopass' ? 'selected' : ''}>Sieć otwarta</option>
          </select>
        </label>
      </div>` : ''}

      <div class="notif">
        <label class="sw"><span>Powiadom mnie, gdy ktoś zeskanuje brelok</span>
          <input type="checkbox" name="notifyActive" value="1" ${isNotifyActive ? 'checked' : ''}><i></i></label>
        
        <div id="tgStatusArea">
          ${caps.tg ? (d.notifyTg
            ? `<div class="paired">✓ Telegram jest połączony</div>
               <label class="unlink"><input type="checkbox" name="unlinkTg" value="1"> Odłącz Telegram przy zapisie</label>`
            : (caps.pairUrl
              ? `<a class="btn pair" id="btnPairTg" href="${esc(caps.pairUrl)}" target="_blank" rel="noopener">Połącz z aplikacją Telegram</a>
                 <button type="button" class="btn btn-manual-check" id="btnManualCheck" onclick="checkTg()">Sprawdź połączenie</button>
                 <p class="hint">Kliknij, wciśnij START w Telegramie i wróć tutaj.</p>`
              : '')) : ''}
        </div>

        ${caps.tg ? `<details><summary>Nie działa? Połącz ręcznie</summary>
          ${field('Numer z Telegrama', 'notifyTg', d.notifyTg || '', d.notifyTg ? 'Zapisano' : 'Wklej numer od bota')}
          <p class="hint">Napisz dowolną wiadomość do ${caps.bot ? `<a href="https://t.me/${esc(caps.bot)}" target="_blank" rel="noopener">@${esc(caps.bot)}</a>` : 'bota'} w Telegramie. Odeśle Ci numer. Wklej go tutaj.</p></details>` : ''}
        
        ${caps.mail ? field('E-mail do powiadomień', 'notifyEmail', d.notifyEmail, 'Twój adres e-mail', 'email') : ''}
      </div>

      <div class="guide">
        <b>Wskazówka skanowania NFC:</b><br>
        • iPhone: zbliżaj brelok do górnej krawędzi telefonu.<br>
        • Android: moduł NFC znajduje się zwykle na środku pleców telefonu (upewnij się, że opcja NFC jest włączona w ustawieniach).
      </div>

      <div class="linkbox">
        <b>Twój link do panelu</b>
        <p>To jedyny sposób, żeby tu wrócić i zmienić dane breloka. Zapisz go i nie pokazuj nikomu.</p>
        ${linkActions}
      </div>

      <div class="legal-foot"><a href="/privacy" target="_blank">Polityka Prywatności i Bezpieczeństwo Danych</a></div>

      ${d.termsAt ? '' : `<label class="unlink" style="align-items:flex-start;font-size:13px;font-weight:500;line-height:1.5"><input type="checkbox" name="terms" value="1" style="margin-top:3px;flex:none"><span>Mam ukończone 16 lat i zapoznałem/am się z <a href="/privacy" target="_blank">Polityką Prywatności</a>.</span></label>`}
      <div class="actions">
        <button type="submit" name="after" value="" class="btn save">Zapisz zmiany</button>
        <button type="submit" name="after" value="preview" class="btn alt">Zapisz i zobacz profil</button>
      </div>

      <details class="more">
        <summary>Więcej opcji</summary>
        <div class="more-body">
          <p>Czyści wszystkie wypełnione pola w formularzu. Nic nie zostanie usunięte z breloka, dopóki nie klikniesz „Zapisz zmiany”. Odświeżenie strony cofa czyszczenie.</p>
          <button type="button" class="clearbtn" id="clearAll">Wyczyść wszystkie pola</button>
          <p style="margin-top:16px">Jeśli ktoś niepowołany mógł zdobyć link do tego panelu, wygeneruj nowy. Stary przestanie działać od razu, a zmiany z formularza zostaną zapisane.</p>
          <p style="margin-top:18px"><b>Twoje dane (RODO)</b><br>Możesz pobrać wszystko, co o Tobie przechowujemy, albo trwale usunąć dane i dezaktywować brelok.</p>
          <a class="clearbtn" style="display:inline-block;text-decoration:none;text-align:center" href="/admin?tag=${encodeURIComponent(tagId)}&token=${encodeURIComponent(token)}&export=1">Pobierz moje dane (JSON)</a>
          <input type="text" name="eraseConfirm" placeholder="Wpisz USUŃ, aby potwierdzić" autocomplete="off" style="margin-top:12px">
          <button type="submit" name="erase" value="1" class="clearbtn" style="color:#b91c1c" onclick="return confirm('Trwale usunąć wszystkie dane i dezaktywować ten brelok? Tego nie można cofnąć.')">Usuń moje dane i dezaktywuj brelok</button>
          <button type="submit" name="rotate" value="1" class="clearbtn" onclick="return confirm('Wygenerować nowy link do panelu? Stary przestanie działać.')">Wygeneruj nowy link do panelu</button>
        </div>
      </details>
    </form>
  </main>
  <div class="toast" id="toast" role="status" aria-live="polite"></div>`;
  const script = `
    var MODE_DESC = ${jsonForScript(MODE_DESC)};
    function show(v){
      document.querySelectorAll('.sec').forEach(function(e){ e.style.display='none'; });
      var s = document.getElementById('sec-' + v);
      if(s) s.style.display = 'block';
      var md = document.getElementById('modeDesc');
      if(md) md.textContent = MODE_DESC[v] || '';
    }
    document.querySelectorAll('input[name=mode]').forEach(function(r){
      r.addEventListener('change', function(){ show(r.value); });
    });
    var current = ${jsonForScript(t)};
    show(current);

    var TID = ${jsonForScript(tagId)}, TOK = ${jsonForScript(token)};

    var isPolling = false;
    var pollLoopTimer = null;

    function applyPaired(chatId){
      var area = document.getElementById('tgStatusArea');
      if(!area) return;
      area.innerHTML = '<div class="paired">✓ Telegram jest połączony</div>' +
                       '<label class="unlink"><input type="checkbox" name="unlinkTg" value="1"> Odłącz Telegram przy zapisie</label>';
      var inp = document.querySelector('input[name="notifyTg"]');
      if(inp) inp.value = chatId;
    }

    var urlParams = new URLSearchParams(window.location.search);
    var tgPaired = urlParams.get('tg_paired');
    if (tgPaired) {
      applyPaired(tgPaired);
    }

    function checkTg(){
      return fetch('/api/check-status?tag=' + encodeURIComponent(TID) +
                   '&token=' + encodeURIComponent(TOK) + '&_=' + Date.now(), {
                     cache: 'no-store',
                     headers: { 'Cache-Control': 'no-cache', 'Pragma': 'no-cache' }
                   })
        .then(function(r){ return r.json(); })
        .then(function(res){
          if(res && res.ok && res.pairedTg){
            isPolling = false;
            if(pollLoopTimer){ clearTimeout(pollLoopTimer); pollLoopTimer = null; }
            applyPaired(res.chatId);
            return true;
          }
          return false;
        })
        .catch(function(){ return false; });
    }

    function runPoll(attempt){
      if(!isPolling || attempt > 15) return;
      checkTg().then(function(success){
        if(!success && isPolling){
          pollLoopTimer = setTimeout(function(){ runPoll(attempt + 1); }, 2500);
        }
      });
    }

    var pairBtn = document.getElementById('btnPairTg');
    var manualBtn = document.getElementById('btnManualCheck');
    if(pairBtn){
      pairBtn.addEventListener('click', function(){
        isPolling = true;
        pairBtn.innerText = 'Oczekiwanie na połączenie...';
        pairBtn.style.opacity = '0.7';
        if(manualBtn) manualBtn.style.display = 'flex';
        setTimeout(function(){ runPoll(1); }, 1500);
      });
    }

    var lastWake = 0;
    function onWake(){
      var now = Date.now();
      if(now - lastWake < 3000) return;
      lastWake = now;
      if(!document.querySelector('.paired')){
        checkTg();
      }
    }

    window.addEventListener('focus', onWake);
    window.addEventListener('pageshow', onWake);
    document.addEventListener('visibilitychange', function(){
      if(document.visibilityState === 'visible') onWake();
    });

    var ADMIN_URL = ${jsonForScript(currentAdminUrl || '')} || window.location.href;
    var toastEl = document.getElementById('toast'), toastTimer = null;
    function toast(text){
      if(!toastEl) return;
      toastEl.textContent = text;
      toastEl.classList.add('show');
      clearTimeout(toastTimer);
      toastTimer = setTimeout(function(){ toastEl.classList.remove('show'); }, 4200);
    }
    function flash(btn, text){
      var sp = btn.querySelector('span'), old = sp.textContent;
      sp.textContent = text;
      setTimeout(function(){ sp.textContent = old; }, 2200);
    }
    function copyText(v){
      return (navigator.clipboard ? navigator.clipboard.writeText(v) : Promise.reject()).catch(function(){
        var t = document.createElement('textarea'); t.value = v; document.body.appendChild(t); t.select(); document.execCommand('copy'); t.remove();
      });
    }
    document.querySelectorAll('.js-copy').forEach(function(btn){
      btn.onclick = function(){
        copyText(ADMIN_URL).then(function(){
          flash(btn, 'Skopiowano link!');
          toast('Skopiowano. Wklej link do notatek albo wyślij go sobie w wiadomości.');
        });
      };
    });

    var form = document.querySelector('form');
    var dirtyBar = document.getElementById('dirtyBar'), prevLink = document.getElementById('prevLink'), dirty = false;
    function markDirty(){
      if(dirty) return;
      dirty = true;
      if(dirtyBar) dirtyBar.classList.add('show');
      if(prevLink) prevLink.classList.add('dim');
    }
    if(form){
      form.addEventListener('input', markDirty);
      form.addEventListener('change', markDirty);
      form.addEventListener('submit', function(){ dirty = false; });
    }
    if(prevLink){
      prevLink.addEventListener('click', function(e){
        if(dirty){ e.preventDefault(); toast('Najpierw zapisz zmiany. Wtedy zobaczysz je w profilu.'); }
      });
    }

    var clearBtn = document.getElementById('clearAll');
    if(clearBtn){
      clearBtn.addEventListener('click', function(){
        if(!window.confirm('Wyczyścić wszystkie wypełnione pola? Zmiany zatwierdzisz dopiero przyciskiem „Zapisz zmiany”.')) return;
        document.querySelectorAll('.sec input, .sec textarea').forEach(function(el){
          var t = (el.type || '').toLowerCase();
          if(el.tagName === 'TEXTAREA' || t === 'text' || t === 'url' || t === 'tel' || t === 'email' || t === 'password' || t === 'number'){
            el.value = '';
          }
        });
        markDirty();
        window.scrollTo(0, 0);
        toast('Pola wyczyszczone. Kliknij „Zapisz zmiany”, aby zatwierdzić.');
      });
    }

    var SAVED = ${msg ? 'true' : 'false'};
    if(SAVED){
      window.scrollTo(0, 0);
      toast('✓ Zapisano. Twoje dane są już na breloku.');
      try {
        var cu = new URL(window.location.href);
        cu.searchParams.delete('saved');
        history.replaceState(null, '', cu.pathname + cu.search);
      } catch(e) {}
    }
  `;
  return shell({ title: 'Brelok #' + tagId, theme: '#eef1f5', font: 'Manrope:wght@500;600;700;800', css, body, script });
}

// ---------- Adapter: Node http -> Fetch API (Request/Response) ----------
const ctx = {
  waitUntil(p) { Promise.resolve(p).catch((e) => console.error('waitUntil:', e)); }
};

const MAX_BODY = 100_000;
function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = []; let size = 0, done = false;
    req.on('data', (c) => {
      if (done) return;
      size += c.length;
      if (size > MAX_BODY) { done = true; reject(Object.assign(new Error('too large'), { status: 413 })); return; }
      chunks.push(c);
    });
    req.on('end', () => { if (!done) { done = true; resolve(Buffer.concat(chunks)); } });
    req.on('error', (e) => { if (!done) { done = true; reject(e); } });
  });
}

let baseHost = '', baseProto = 'https';
try { if (env.BASE_URL) { const b = new URL(env.BASE_URL); baseHost = b.host; baseProto = b.protocol.replace(':', ''); } } catch (e) {}

// Dozwolone hosty (ochrona przed podrobionym Host / X-Forwarded-Host). Dodatkowe: ALLOWED_HOSTS=a.pl,b.pl
const ALLOWED_HOSTS = new Set([baseHost, ...listOf(process.env.ALLOWED_HOSTS).map((x) => x.toLowerCase())].filter(Boolean));
function pickHost(req, first) {
  const cand = (TRUST_PROXY ? first(req.headers['x-forwarded-host']) : '') || req.headers.host || '';
  const c = cand.toLowerCase();
  if (!ALLOWED_HOSTS.size || ALLOWED_HOSTS.has(c) || /^(localhost|127\.0\.0\.1|\[::1\])(:\d+)?$/.test(c)) return cand || `localhost:${env.PORT}`;
  return baseHost || cand;
}

const server = http.createServer(async (req, res) => {
  try {
    const first = (v) => String(v || '').split(',')[0].trim();
    const host = pickHost(req, first);
    const proto = host === baseHost ? baseProto : (TRUST_PROXY ? first(req.headers['x-forwarded-proto']) : '') || 'http';
    const ip = clientIp(req);

    const headers = new Headers();
    for (const [k, v] of Object.entries(req.headers)) {
      if (Array.isArray(v)) v.forEach((x) => headers.append(k, x)); else if (v !== undefined) headers.set(k, v);
    }
    headers.set('cf-connecting-ip', ip);

    const init = { method: req.method, headers };
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      let buf;
      try { buf = await readBody(req); }
      catch (e) {
        res.writeHead(e.status || 400, { 'Content-Type': 'text/plain;charset=UTF-8', Connection: 'close' });
        return res.end(e.status === 413 ? 'Za duże żądanie.' : 'Błąd żądania.');
      }
      init.body = buf;
    }

    const request = new Request(`${proto}://${host}${req.url}`, init);
    const response = await worker.fetch(request, env, ctx);

    const out = {};
    response.headers.forEach((v, k) => { out[k] = v; });
    res.writeHead(response.status, out);
    if (req.method === 'HEAD' || response.status === 204 || response.status === 304 || !response.body) return res.end();
    res.end(Buffer.from(await response.arrayBuffer()));
  } catch (err) {
    console.error('Błąd serwera:', err);
    if (!res.headersSent) res.writeHead(500, { 'Content-Type': 'text/plain;charset=UTF-8' });
    res.end('Błąd serwera.');
  }
});

// Codzienna kopia bazy (SQLite online backup). BACKUP=0 wylacza, BACKUP_DIR, BACKUP_KEEP (domyslnie 14 sztuk).
const BACKUP_DIR = process.env.BACKUP_DIR || path.join(__dir, 'backups');
const BACKUP_KEEP = Number(process.env.BACKUP_KEEP) || 14;
async function backupDb() {
  try {
    fs.mkdirSync(BACKUP_DIR, { recursive: true });
    const stamp = new Date().toISOString().replace(/[:T]/g, '-').slice(0, 16);
    const file = path.join(BACKUP_DIR, `database-${stamp}.sqlite`);
    await db.backup(file);
    const all = fs.readdirSync(BACKUP_DIR).filter((f) => /^database-.*\.sqlite$/.test(f)).sort();
    for (const f of all.slice(0, Math.max(0, all.length - BACKUP_KEEP))) fs.unlinkSync(path.join(BACKUP_DIR, f));
    console.log('[backup] OK', file);
  } catch (e) { console.error('[backup] błąd:', e); }
}
if (process.env.BACKUP !== '0') {
  setTimeout(backupDb, 30_000).unref();
  setInterval(backupDb, 24 * 3600 * 1000).unref();
}

if (!process.env.LEGAL_NAME || !process.env.CONTACT_EMAIL) console.warn('[RODO] Uzupełnij LEGAL_NAME i CONTACT_EMAIL w .env - polityka prywatności pokazuje puste pola!');
// HOST=127.0.0.1 gdy proxy/tunel dziala na tej samej maszynie (wtedy port nie jest widoczny z internetu)
server.listen(env.PORT, process.env.HOST || '::', () => {
  console.log(`Server ${BRAND} działa na porcie ${env.PORT} (baza: ${DB_PATH})`);
});

process.on('unhandledRejection', (e) => console.error('unhandledRejection:', e));
process.on('SIGTERM', () => { server.close(() => { db.close(); process.exit(0); }); });
process.on('SIGINT', () => { server.close(() => { db.close(); process.exit(0); }); });