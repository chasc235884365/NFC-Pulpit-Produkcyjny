#!/usr/bin/env bash
# TapCraft - zaszyfrowana kopia bazy POZA serwer (uruchamiaj z crona raz dziennie).
# Bierze najnowszy plik z backups/ (zrobiony przez server.js), sprawdza go, kompresuje,
# szyfruje (AES-256) i wysyla: do rclone (DEST=nazwa:folder) albo do katalogu (DEST=/sciezka).
set -euo pipefail

APP_DIR="${APP_DIR:-$HOME/tapcraft/server}"      # katalog z server.js
SRC_DIR="${SRC_DIR:-$APP_DIR/backups}"
KEY_FILE="${KEY_FILE:-$HOME/.tapcraft_backup_key}" # haslo do szyfrowania (chmod 600)
DEST="${DEST:-}"                                  # np. b2:tapcraft-backups  albo  /mnt/dysk/tapcraft
KEEP_DAYS="${KEEP_DAYS:-30}"                      # po ilu dniach kasowac stare kopie (zgodnie z polityka prywatnosci: 30)
PING_URL="${PING_URL:-}"                          # opcjonalnie: adres z healthchecks.io

[ -n "$DEST" ]      || { echo "BLAD: ustaw DEST (np. DEST=b2:tapcraft-backups)"; exit 1; }
[ -s "$KEY_FILE" ]  || { echo "BLAD: brak klucza $KEY_FILE (patrz instrukcja)"; exit 1; }

latest="$(ls -1t "$SRC_DIR"/database-*.sqlite 2>/dev/null | head -1 || true)"
[ -n "$latest" ] || { echo "BLAD: brak plikow database-*.sqlite w $SRC_DIR"; exit 1; }

# kopia starsza niz 36 h = codzienny backup serwera nie dziala
if [ -n "$(find "$latest" -mmin +2160 2>/dev/null)" ]; then echo "UWAGA: najnowsza kopia ma ponad 36 h"; exit 1; fi

if command -v sqlite3 >/dev/null 2>&1; then
  [ "$(sqlite3 "$latest" 'PRAGMA integrity_check;')" = "ok" ] || { echo "BLAD: kopia uszkodzona"; exit 1; }
fi

tmp="$(mktemp -d)"; trap 'rm -rf "$tmp"' EXIT
name="$(basename "$latest").gz.enc"
gzip -c "$latest" | openssl enc -aes-256-cbc -pbkdf2 -iter 200000 -salt -pass "file:$KEY_FILE" -out "$tmp/$name"

if [[ "$DEST" == /* ]]; then
  mkdir -p "$DEST"; cp "$tmp/$name" "$DEST/"
  find "$DEST" -name 'database-*.enc' -mtime +"$KEEP_DAYS" -delete
else
  rclone copyto "$tmp/$name" "$DEST/$name"
  rclone delete "$DEST" --min-age "${KEEP_DAYS}d" --include 'database-*.enc'
fi

[ -z "$PING_URL" ] || curl -fsS -m 10 "$PING_URL" >/dev/null || true
echo "OK: wyslano $name -> $DEST"
