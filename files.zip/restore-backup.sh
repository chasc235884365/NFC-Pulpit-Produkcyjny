#!/usr/bin/env bash
# Odtwarzanie bazy z zaszyfrowanej kopii.  Uzycie:
#   ./restore-backup.sh database-2026-11-25-03-00.sqlite.gz.enc  /sciezka/do/database.sqlite
# PRZED uruchomieniem zatrzymaj aplikacje:  pm2 stop tapcraft   (a po: pm2 start tapcraft)
set -euo pipefail
KEY_FILE="${KEY_FILE:-$HOME/.tapcraft_backup_key}"
in="${1:?podaj plik .enc}"; out="${2:?podaj docelowy plik database.sqlite}"
[ -s "$KEY_FILE" ] || { echo "BLAD: brak klucza $KEY_FILE"; exit 1; }
[ ! -e "$out" ] || cp "$out" "$out.przed-odtworzeniem.$(date +%s)"
openssl enc -d -aes-256-cbc -pbkdf2 -iter 200000 -pass "file:$KEY_FILE" -in "$in" | gunzip > "$out.tmp"
if command -v sqlite3 >/dev/null 2>&1; then [ "$(sqlite3 "$out.tmp" 'PRAGMA integrity_check;')" = "ok" ] || { echo "BLAD: odtworzona baza uszkodzona"; rm -f "$out.tmp"; exit 1; }; fi
rm -f "$out-wal" "$out-shm"; mv "$out.tmp" "$out"
echo "OK: odtworzono $out"
